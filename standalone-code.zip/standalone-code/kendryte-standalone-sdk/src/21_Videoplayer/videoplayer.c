/**
 ****************************************************************************************************
 * @file        videoplay.c
 * @author      正点原子团队(ALIENTEK)
 * @version     V1.0
 * @date        2024-01-01
 * @brief       视频播放器 应用代码
 * @license     Copyright (c) 2020-2032, 广州市星翼电子科技有限公司
 ****************************************************************************************************
 * @attention
 *
 * 实验平台:正点原子 K210开发板
 * 在线视频:www.yuanzige.com
 * 技术论坛:www.openedv.com
 * 公司网址:www.alientek.com
 * 购买地址:openedv.taobao.com
 *
 ****************************************************************************************************
 */
 
#include "videoplayer.h"
#include "sleep.h" 
#include "iomem.h"
#include "i2s.h"
#include "lcd.h"
#include "key.h"
#include "./MJPEG/mjpeg.h"
#include "./MJPEG/avi.h"
#include "image_process.h"
#include "timer.h"
#include "string.h"

uint32_t g_count;
uint16_t g_avi_frame;                             /* 播放帧率 */
volatile uint8_t g_avi_frameup;                   /* 视频播放时隙控制变量,当等于1的时候,可以更新下一帧视频 */
uint8_t *p_avi_i2s_buf[AVI_AUDIO_BUF_NUM];        /* 音频缓冲帧 */
extern uint16_t lcd_gram[320 * 16];


/**
 * @brief       定时器中断回调
 * @param       ctx    : 回调参数
 * @retval      0
 */
int timer_timeout_cb(void *ctx) {
    // uint32_t *tmp = (uint32_t *)(ctx);
    g_avi_frameup = 1;
    return 0;
}

/**
 * @brief       显示当前播放时间
 * @param       favi    : 当前播放的视频文件
 * @param       aviinfo : avi控制结构体
 * @retval      无
 */
void video_time_show(FIL *favi, AVI_INFO *aviinfo)
{
    static uint32_t oldsec;                                         /* 上一次的播放时间 */
    
    uint8_t *buf;
    
    uint32_t totsec = 0;                                            /* video文件总时间 */
    uint32_t cursec;                                                /* 当前播放时间 */
    
    totsec = (aviinfo->SecPerFrame / 1000) * aviinfo->TotalFrame;   /* 歌曲总长度(单位:ms) */
    totsec /= 1000;                                                 /* 秒钟数. */
    cursec = ((double)favi->fptr / favi->obj.objsize) * totsec;     /* 获取当前播放到多少秒 */
    
    if (oldsec != cursec)                                           /* 需要更新显示时间 */
    {
        buf = iomem_malloc(100);                                /* 申请100字节内存 */
        oldsec = cursec;
        
        sprintf((char *)buf, "Play time:%02d:%02d:%02d/%02d:%02d:%02d", cursec / 3600, (cursec % 3600) / 60, cursec % 60, totsec / 3600, (totsec % 3600) / 60, totsec % 60);
        /* 显示字符的形式太慢了，会导致卡顿，这里以刷图的形式 */
        // lcd_draw_fill_rectangle(10 + 8 * 10, 40, 10 + 18 * 8, 40 + 16, WHITE);
        // lcd_draw_string(10, 40, (char *)buf, RED);   /* 显示*/
        for (size_t i = 0; i < 320 * 16; i++)
        {
            lcd_gram[i] = 0xFFFF;
        }
        draw_string_rgb565_image(lcd_gram, 320, 240, 10, 0, (char *)buf, BLUE);
        lcd_draw_picture(0, 50, 320, 16, (uint16_t *)lcd_gram);   
        iomem_free(buf);
    }
}

/**
 * @brief       显示当前视频文件的相关信息
 * @param       aviinfo : avi控制结构体
 * @retval      无
 */
void video_info_show(AVI_INFO *aviinfo)
{
    uint8_t *buf;
    
    buf = iomem_malloc(100);                                                /* 申请100字节内存 */
    
    sprintf((char *)buf, "Track:%d,Sampling rate:%d", aviinfo->Channels, aviinfo->SampleRate * 10);
    lcd_draw_string(10, 0, (char *)buf, RED); 
    
    sprintf((char *)buf, "Frame rate:%d", 1000 / (aviinfo->SecPerFrame / 1000));
    lcd_draw_string(10, 20, (char *)buf, RED);  
    
    iomem_free(buf);                                                        /* 释放内存 */
}

/**
 * @brief       播放一个mjpeg文件
 * @param       pname : 文件名
 * @retval      res
 *   @arg       KEY0_PRES , 下一曲.
 *   @arg       KEY1_PRES , 上一曲.
 *   @arg       其他 , 错误
 */
uint8_t video_play_mjpeg(uint8_t *pname)
{
    uint8_t *framebuf;  /* 视频解码buf */
    uint8_t *pbuf;      /* buf指针 */
    FIL *favi;
    uint8_t  res = 0;
    uint8_t i = 0;
    uint16_t offset = 0;
    uint32_t nr;
    uint8_t i2ssavebuf;

    for (i = 0; i < AVI_AUDIO_BUF_NUM; i++)
    {
        p_avi_i2s_buf[i] = iomem_malloc(AVI_AUDIO_BUF_SIZE);    /* 申请音频内存 */
        
        if (p_avi_i2s_buf[i] == NULL)                               /* 申请失败, 直接退出 */
        {
            break;
        }
        
        memset(p_avi_i2s_buf[i], 0, AVI_AUDIO_BUF_SIZE);            /* 数据清零 */
    }
    
    favi = (FIL *)iomem_malloc(sizeof(FIL));                    /* 申请favi内存 */
    framebuf = iomem_malloc(AVI_VIDEO_BUF_SIZE) ;               /* 申请视频buf */
    
    if (!framebuf)  /* 只要最后这个视频buf申请失败, 前面的申请失不失败都不重要, 总之就是失败了 */
    {
        printf("memory error!\r\n");
        res = 0XFF;
    }

    while (res == 0)
    {
        printf("open file\r\n");
        res = f_open(favi, (char *)pname, FA_READ);
        if (res == 0)
        {
            printf("file open success\n");
            pbuf = framebuf;
            res = f_read(favi, pbuf, AVI_VIDEO_BUF_SIZE, &nr);      /* 开始读取 */
            
            if (res)
            {
                printf("fread error:%d\r\n", res);
                break;
            }
            printf("file read success\n");
            /* 开始avi解析 */
            res = avi_init(pbuf, AVI_VIDEO_BUF_SIZE);               /* avi解析 */
            if (res)
            {
                printf("avi err:%d\r\n", res);
                break;
            }

            video_info_show(&g_avix);
            timer_init(TIMER_DEVICE_0);
            /* 设置定时器超时时间，单位为ns */
            timer_set_interval(TIMER_DEVICE_0, TIMER_CHANNEL_0, g_avix.SecPerFrame / 100 * 1e5);
            /* 设置定时器中断回调 */
            timer_irq_register(TIMER_DEVICE_0, TIMER_CHANNEL_0, 0, 1, timer_timeout_cb, &g_count);
            /* 使能定时器 */
            timer_set_enable(TIMER_DEVICE_0, TIMER_CHANNEL_0, 1);


            offset = avi_srarch_id(pbuf, AVI_VIDEO_BUF_SIZE, "movi");                   /* 寻找movi ID */
            avi_get_streaminfo(pbuf + offset + 4);                                      /* 获取流信息 */
            f_lseek(favi, offset + 12);                                                 /* 跳过标志ID,读地址偏移到流数据开始处 */
            res = mjpegdec_init((320 - g_avix.Width) / 2, (240 - g_avix.Height));       /* JPG解码初始化 */

            if (g_avix.SampleRate)                                                      /* 有音频信息,才初始化 */
            {
                printf("i2s init !\r\n");
                /* 初始化I2S，第三个参数为设置通道掩码，通道0:0x03,通道1：0x0C,通道2：0x30,通道3:0xC0 */
                i2s_init(I2S_DEVICE_0, I2S_TRANSMITTER, 0x03);
                /* 设置I2S发送数据的通道参数 */
                i2s_tx_channel_config(
                    I2S_DEVICE_0, /* I2S设备号*/
                    I2S_CHANNEL_0, /* I2S通道 */
                    RESOLUTION_16_BIT, /* 接收数据位数 */
                    SCLK_CYCLES_32, /* 单个数据时钟数 */
                    TRIGGER_LEVEL_4, /* DMA触发时FIFO深度 */
                    STANDARD_MODE); /* 工作模式 */
                            
                i2s_set_sample_rate(I2S_DEVICE_0, g_avix.SampleRate);   /* 设置采样率 */

                i2ssavebuf = 0;
            }

            while (1)          /* 播放循环 */
            {
                if (g_avix.StreamID == AVI_VIDS_FLAG)                                   /* 视频流 */
                {
                    pbuf = framebuf;
                    f_read(favi, pbuf, g_avix.StreamSize + 8, &nr);                     /* 读入整帧+下一数据流ID信息 */
                    res = mjpegdec_decode(pbuf, g_avix.StreamSize);
                    if (res)
                    {
                        printf("decode error!\r\n");
                    }

                    while (g_avi_frameup == 0);   /* 待时间到达(在TIM7的中断里面设置为1) */

                    g_avi_frameup = 0;            /* 标志清零 */
                    g_avi_frame++;
                }
                else                             /* 音频流 */
                {
                    i2ssavebuf++;
                    if (i2ssavebuf >=  AVI_AUDIO_BUF_NUM)
                    {
                        i2ssavebuf = 0;
                    }

                    f_read(favi, p_avi_i2s_buf[i2ssavebuf], g_avix.StreamSize + 8, &nr);    /* 填充p_avi_sai_buf */
                    pbuf = p_avi_i2s_buf[i2ssavebuf];

                    i2s_play(
                        I2S_DEVICE_0, /* I2S设备号 */
                        DMAC_CHANNEL1, /* DMA通道号 */ 
                        p_avi_i2s_buf[i2ssavebuf], /* 播放的PCM数据 */
                        g_avix.StreamSize, /* PCM数据的长度 */
                        g_avix.StreamSize / 4, /* 单次发送数量 */
                        16, /* 单次采样位宽 */
                        2); /* 声道数 */
                    video_time_show(favi, &g_avix);     /* 显示当前播放时间，开启可能会卡 */
                } 
 
                if (avi_get_streaminfo(pbuf + g_avix.StreamSize))  /* 读取下一帧 流标志 */
                {
                    printf("g_frame error \r\n");
                    res = KEY0_PRES;
                    break;
                }
            }

            timer_set_enable(TIMER_DEVICE_0, TIMER_CHANNEL_0, 0);
            // lcd_set_area(0, 0, 320, 240);     /* 恢复窗口 */
            mjpegdec_free();                                       /* 释放内存 */
            f_close(favi);                                         /* 关闭文件 */
        }
    }

   /* 释放内存 */
    for(i = 0; i < AVI_AUDIO_BUF_NUM; i++)
    {
        iomem_free(p_avi_i2s_buf[i]);
    }
    iomem_free(framebuf);
    iomem_free(favi);

    return res;
}

/**
 * @brief       AVI文件查找
 * @param       favi    : AVI文件
 * @param       aviinfo : AVI信息结构体
 * @param       mbuf    : 数据缓冲区
 * @retval      执行结果
 *   @arg       0    , 成功
 *   @arg       其他 , 错误
 */
uint8_t video_seek(FIL *favi, AVI_INFO *aviinfo, uint8_t *mbuf)
{
    uint32_t fpos = favi->fptr;
    uint8_t *pbuf;
    uint16_t offset;
    uint32_t br;
    uint32_t delta;
    uint32_t totsec;
    uint8_t key;

    totsec = (aviinfo->SecPerFrame / 1000) * aviinfo->TotalFrame;
    totsec /= 1000;                             /* 秒钟数 */
    delta = (favi->obj.objsize / totsec) * 5;   /* 每次前进5秒钟的数据量 */

    while (1)
    {
        key = key_scan(1);
        if (key == KEY0_PRES)                   /* 快进 */
        {
            if (fpos < favi->obj.objsize)
            {
                fpos += delta;
            }

            if (fpos > (favi->obj.objsize - AVI_VIDEO_BUF_SIZE))
            {
                fpos = favi->obj.objsize - AVI_VIDEO_BUF_SIZE;
            }
        }
        else if (key == KEY1_PRES)              /* 快退 */
        {
            if (fpos > delta)
            {
                fpos -= delta;
            }
            else
            {
                fpos = 0;
            }
        }
        else 
        {
            break;
        }

        f_lseek(favi, fpos);
        f_read(favi, mbuf, AVI_VIDEO_BUF_SIZE, &br);       /* 读入整帧+下一数据流ID信息 */
        pbuf = mbuf;
        
        if (fpos == 0)                                     /* 从0开始,得先寻找movi ID */
        {
            offset = avi_srarch_id(pbuf, AVI_VIDEO_BUF_SIZE, "movi");
        }
        else
        {
            offset = 0;
        }

        offset += avi_srarch_id(pbuf + offset, AVI_VIDEO_BUF_SIZE, g_avix.VideoFLAG); /* 寻找视频帧 */
        avi_get_streaminfo(pbuf + offset);                  /* 获取流信息 */
        f_lseek(favi, fpos + offset + 8);                   /* 跳过标志ID,读地址偏移到流数据开始处 */
        
        if (g_avix.StreamID == AVI_VIDS_FLAG)
        {
            f_read(favi, mbuf, g_avix.StreamSize + 8, &br); /* 读入整帧 */
            mjpegdec_decode(mbuf, g_avix.StreamSize);       /* 显示视频帧 */
        }
        else
        {
            printf("error flag");
        }

        video_time_show(favi, &g_avix);
    }

    return 0;
}



