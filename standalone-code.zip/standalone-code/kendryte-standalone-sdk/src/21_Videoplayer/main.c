/**
 ****************************************************************************************************
 * @file        main.c
 * @author      正点原子团队(ALIENTEK)
 * @version     V1.0
 * @date        2024-01-01
 * @brief       视频播放器 实验
 * @license     Copyright (c) 2020-2032, 广州市星翼电子科技有限公司
 ****************************************************************************************************
 * @attention
 *
 * 实验平台:正点原子 K210开发板
 * 在线视频:www.yuanzige.com
 * 技术论坛:www.openedv.com
 * 公司网址:www.alientek.com
 * 购买地址:openedv.taobao.com
 * 
 ****************************************************************************************************
 */
#include <stddef.h>
#include <stdio.h>
#include "iomem.h"
#include "sysctl.h"
#include "gpio.h"
#include "fpioa.h"
#include "i2s.h"
#include "videoplayer.h"
#include "./BSP/SDCARD/sdcard.h"
#include "./BSP/FATFS/ff.h"
#include "./BSP/KEY/key.h"
#include "./BSP/LCD/lcd.h"
#include "./BSP/SPEAKER/speaker.h"

char *pname = {"0:VIDEO/play.avi"};  

int main(void)
{
    FRESULT res;
    FATFS fs;
    
    sysctl_pll_set_freq(SYSCTL_PLL0, 800000000);
    sysctl_pll_set_freq(SYSCTL_PLL1, 400000000);
    sysctl_pll_set_freq(SYSCTL_PLL2, 45158400);
    sysctl_set_power_mode(SYSCTL_POWER_BANK6, SYSCTL_POWER_V18);
    sysctl_set_power_mode(SYSCTL_POWER_BANK7, SYSCTL_POWER_V18);
    sysctl_set_spi0_dvp_data(1);

    lcd_init();   /* LCD初始化 */
    lcd_set_direction(DIR_YX_LRUD); /* 设置扫描方向 */

    speaker_i2s_hardware_init(); /* 扬声器接口初始化 */
    /* 初始化中断，使能全局中断，初始化dmac */
    plic_init();
    sysctl_enable_irq();
    dmac_init();
    key_init();     /* 按键初始化 */

    if (sd_init() != 0)
    {
        printf("SD card initialization failed!\n");
        while (1);
    }
    printf("SD card initialization succeed!\n");

    /* 文件系统挂载SD卡 */
    res = f_mount(&fs, _T("0:"), 1);
    if (res != FR_OK)
    {
        printf("SD card mount failed! Error code: %d\n", res);
        while (1);
    }
    printf("SD card mount succeed!\n");

    video_play_mjpeg((uint8_t *)pname); /* 播放视频 */
    while (1)
    {
        
    }
}
