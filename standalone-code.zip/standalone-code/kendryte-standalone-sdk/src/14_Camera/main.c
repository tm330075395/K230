/**
 ****************************************************************************************************
 * @file        main.c
 * @author      正点原子团队(ALIENTEK)
 * @version     V1.0
 * @date        2024-01-01
 * @brief       摄像头 实验
 * @license     Copyright (c) 2020-2032, 广州市星翼电子科技有限公司
 ****************************************************************************************************
 * @attention
 *
 * 实验平台:正点原子 K210开发板
 * 在线视频:www.yuanzige.com
 * 技术论坛:www.openedv.com
 * 公司网址:www.alientek.com
 * 购买地址:openedv.taobao.com
 * 
 ****************************************************************************************************
 */

#include <stddef.h>
#include "sysctl.h"
#include "iomem.h"
#include "./BSP/LCD/lcd.h"
#include "./BSP/CAMERA/camera.h"

#define CAMERA_WIDTH    320
#define CAMERA_HEIGHT   240

int main(void)
{
    uint8_t *disp;
    
    sysctl_pll_set_freq(SYSCTL_PLL0, 800000000);
    sysctl_pll_set_freq(SYSCTL_PLL1, 400000000);
    sysctl_pll_set_freq(SYSCTL_PLL2, 45158400);
    sysctl_set_power_mode(SYSCTL_POWER_BANK6, SYSCTL_POWER_V18);
    sysctl_set_power_mode(SYSCTL_POWER_BANK7, SYSCTL_POWER_V18);
    sysctl_set_spi0_dvp_data(1);

    lcd_init();
    lcd_set_direction(DIR_YX_LRUD);
    camera_init(0);
    camera_set_pixformat(PIXFORMAT_RGB565);
    camera_set_framesize(CAMERA_WIDTH, CAMERA_HEIGHT);
    /* 根据摄像头选择是否翻转 */
    camera_set_hmirror(1);
    camera_set_vflip(1);
    
    while (1)
    {
        if (camera_snapshot(&disp, NULL) == 0)
        {
            lcd_draw_picture(0, 0, CAMERA_WIDTH, CAMERA_HEIGHT, (uint16_t *)disp);
            camera_snapshot_release();
        }
    }

}

