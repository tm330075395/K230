/**
 ****************************************************************************************************
 * @file        pwm.c
 * @author      正点原子团队(ALIENTEK)
 * @version     V1.0
 * @date        2024-01-01
 * @brief       PWM输出 驱动代码
 * @license     Copyright (c) 2020-2032, 广州市星翼电子科技有限公司
 ****************************************************************************************************
 * @attention
 * 
 * 实验平台:正点原子 K210开发板
 * 在线视频:www.yuanzige.com
 * 技术论坛:www.openedv.com
 * 公司网址:www.alientek.com
 * 购买地址:openedv.taobao.com
 *
 ****************************************************************************************************
 */

#include "pwm.h"
#include "sysctl.h"
#include "fpioa.h"
#include "plic.h"
#include "../../../../lib/drivers/include/pwm.h"

/**
 * @brief   初始化PWM
 * @param   fre  :PWM输出频率
 * @param   duty :占空比
 * @retval  无
 */
void pwm1_init(double fre, double duty)
{
    /* 系统中断初始化 */
    plic_init();
    sysctl_enable_irq();
    /* 初始化PWM */
    pwm_init(PWM_DEVICE_1);
    /* 设置PWM频率为200KHZ，占空比为0.5的方波 */
    pwm_set_frequency(PWM_DEVICE_1, PWM_CHANNEL_0, fre, duty);
    /* 定时器1输出1（通道0）与红色LED灯引脚绑定 */
    fpioa_set_function(PIN_PWM_LED, FUNC_TIMER1_TOGGLE1);
    /* 使能 PWM 输出 */
    pwm_set_enable(PWM_DEVICE_1, PWM_CHANNEL_0, 1);
}
