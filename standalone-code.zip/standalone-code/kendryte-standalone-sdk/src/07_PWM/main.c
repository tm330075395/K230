/**
 ****************************************************************************************************
 * @file        main.c
 * @author      正点原子团队(ALIENTEK)
 * @version     V1.0
 * @date        2024-01-01
 * @brief       PWM输出 实验
 * @license     Copyright (c) 2020-2032, 广州市星翼电子科技有限公司
 ****************************************************************************************************
 * @attention
 *
 * 实验平台:正点原子 K210开发板
 * 在线视频:www.yuanzige.com
 * 技术论坛:www.openedv.com
 * 公司网址:www.alientek.com
 * 购买地址:openedv.taobao.com
 ****************************************************************************************************
 */
#include <stdio.h>
#include <unistd.h>
#include "pwm.h"
#include "sleep.h"
#include "./BSP/KEY/key.h"
#include "./BSP/PWM/pwm.h"

int main(void)
{
    uint8_t key;
    static double duty_cycle = 0.5;

    key_init();                    /* 按键初始化 */
    pwm1_init(200000, duty_cycle); /* 初始化PWM */

    while(1)
    {
        key = key_scan(0);         /* 得到键值 */
        if (key == KEY0_PRES)
        {
            duty_cycle -= 0.1;
            if (duty_cycle < 0.0)
            {
                duty_cycle = 0.0;
            }
            /* 传入cycle的不同值，调节PWM的占用比，也就是调节灯的亮度 */
            pwm_set_frequency(PWM_DEVICE_1, PWM_CHANNEL_0, 200000, duty_cycle);
        }
        else if(key == KEY1_PRES)
        {
            duty_cycle += 0.1;
            if(duty_cycle > 1.0)
            {
                duty_cycle = 1.0;
            }
            /* 传入cycle的不同值，调节PWM的占用比，也就是调节灯的亮度 */
            pwm_set_frequency(PWM_DEVICE_1, PWM_CHANNEL_0, 200000, duty_cycle);
        }
        else msleep(10);
    }
}
