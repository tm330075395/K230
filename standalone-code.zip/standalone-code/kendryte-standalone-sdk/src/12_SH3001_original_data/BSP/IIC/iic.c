/**
 ****************************************************************************************************
 * @file        iic.c
 * @author      正点原子团队(ALIENTEK)
 * @version     V1.0
 * @date        2024-01-01
 * @brief       IIC 驱动代码
 * @license     Copyright (c) 2020-2032, 广州市星翼电子科技有限公司
 ****************************************************************************************************
 * @attention
 *
 * 实验平台:正点原子 K210开发板
 * 在线视频:www.yuanzige.com
 * 技术论坛:www.openedv.com
 * 公司网址:www.alientek.com
 * 购买地址:openedv.taobao.com
 *
 ****************************************************************************************************
 */

#include "iic.h"
#include "i2c.h"
#include "stdio.h"

static uint16_t _current_addr = 0x00;


/**
 * @brief       IIC初始化，设置从机地址，数据位宽度，I2C通讯速率
 * @param       addr   : 从机地址
 * @retval      返回值 : 无
 */
void i2c_hardware_init(uint16_t addr)
{
    i2c_init(I2C_DEVICE_0, addr, ADDRESS_WIDTH, I2C_CLK_SPEED);
    _current_addr = addr;
}

/**
 * @brief       向寄存器reg写入数据
 * @param       addr    : 从机地址
 * @param       reg     : 寄存器命令
 * @param       length  : 数据长度
 * @param       data_buf: 要写入的数据
 * @retval      返回值  : 0，成功
 *                        1，失败
 */
uint16_t i2c_hd_write(uint8_t addr, uint8_t reg, uint16_t length, uint8_t *data_buf)
{
    uint16_t error = 1;
    uint8_t data[length + 1];

    if (_current_addr != addr)
    {
        i2c_hardware_init(addr);
    }
    
    data[0] = reg;
    for (size_t i = 0; i < length; i++)
    {
    data[i+1] = *data_buf;
    data_buf++;
    }

    error = i2c_send_data(I2C_DEVICE_0, data, length + 1);
    return error;
}

/**
 * @brief       从寄存器reg读取数据
 * @param       addr    : 从机地址
 * @param       reg     : 寄存器命令
 * @param       length  : 数据长度
 * @param       data_buf: 要读取的数据
 * @retval      返回值  : 0，成功
 *                        1，失败
 */
uint16_t i2c_hd_read(uint8_t addr, uint8_t reg, uint16_t length, uint8_t *data_buf)
{
    if (_current_addr != addr)
    {
        i2c_hardware_init(addr);
    }
    uint16_t error = 1;
    
    error = i2c_recv_data(I2C_DEVICE_0, &reg, 1, data_buf, length);
    return error;
}

/**
 * @brief       打印当前I2C总线上的I2C设备地址
 * @param       无
 * @retval      返回值  : 无
 */
void i2c_read_addr(void)
{
    uint16_t error = 1;
    uint8_t cmd[2];
    cmd[0] = 0x00;
    cmd[1] = 0x01;
    
    for (int i = 0; i < 255; i++)
    {
        i2c_init(I2C_DEVICE_0, i, ADDRESS_WIDTH, I2C_CLK_SPEED);
        error = i2c_send_data(I2C_DEVICE_0, cmd, 2);

        if (error == 0)
        {
            printf("I2C DEVICE FOUND:");
            printf("0x");
            printf("%x", i);
        }
        else
        {
            printf(".");
        }
    }
    printf(" \n");
}
