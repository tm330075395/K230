/**
 ****************************************************************************************************
 * @file        main.c
 * @author      正点原子团队(ALIENTEK)
 * @version     V1.0
 * @date        2024-01-01
 * @brief       SH3001读取原始数据 实验
 * @license     Copyright (c) 2020-2032, 广州市星翼电子科技有限公司
 ****************************************************************************************************
 * @attention
 *
 * 实验平台:正点原子 K210开发板
 * 在线视频:www.yuanzige.com
 * 技术论坛:www.openedv.com
 * 公司网址:www.alientek.com
 * 购买地址:openedv.taobao.com
 * 
 ****************************************************************************************************
 */

#include "sleep.h"
#include "sysctl.h"
#include "image_process.h"
#include "./BSP/SH3001/sh3001.h"
#include "./BSP/IIC/iic.h"
#include "./BSP/LCD/lcd.h"
#include "./BSP/LCD/lcdfont.h"

static uint16_t lcd_gram[320 * 240] __attribute__((aligned(32))); /* 定义一个LCD显示缓存区 */

/**
 * @brief       显示数据
 *  @note       以图片显示的方式更快  
 * @param       x, y : 坐标
 * @param       title: 标题
 * @param       data: 角度
 * @retval      无
 */
void user_show_data(uint16_t x, uint16_t y, char * title, short data)
{
    char buf[15];

    sprintf(buf,"%s%d", title, data);          /* 格式化输出 */
    draw_fill_rectangle_image(lcd_gram, 320, x, y, x + 120, y + 16, WHITE);  /* 清除上次缓存数据 */
    draw_string_rgb565_image(lcd_gram, 320, 240, x, y, buf, BLUE); /* 将字符串写入LCD缓存区 */

    // lcd_draw_fill_rectangle(x, y, x + 120, y + 16, WHITE);   /* 清除上次数据(最多显示15个字符,15*8=120) */
    // lcd_draw_string(x, y, buf, BLUE);  /* 显示字符串 */
}

int main(void)
{
    uint8_t t = 0;
    float temperature;                          /* 温度值 */
    short acc_data[3];                          /* 加速度传感器原始数据 */
    short gyro_data[3];                         /* 陀螺仪原始数据 */

    sysctl_pll_set_freq(SYSCTL_PLL0, 800000000);
    sysctl_pll_set_freq(SYSCTL_PLL1, 400000000);
    sysctl_pll_set_freq(SYSCTL_PLL2, 45158400);
    sysctl_set_power_mode(SYSCTL_POWER_BANK6, SYSCTL_POWER_V18);
    sysctl_set_power_mode(SYSCTL_POWER_BANK7, SYSCTL_POWER_V18);
    sysctl_set_spi0_dvp_data(1);

    lcd_init();
    lcd_set_direction(DIR_YX_LRUD);

    /* 初始化 IMU */
    while (sh3001_init())     /* 检测不到SH3001 */
    {
        msleep(10);
    }
    msleep(500);

    /* 清空LCD缓存区 */
    for (size_t i = 0; i < 320 * 240; i++)
    {
        lcd_gram[i] = 0xFFFF;
    }
                              
    while (1)
    {
        t++;
        sh3001_get_imu_compdata(acc_data, gyro_data); /* 读取原始数据 */

        if (t == 20)
        {        
            temperature = sh3001_get_tempdata();    /* 读取温度值 */
            printf("\r\ntemp=%.2f\r\n", temperature);
            // lcd_clear(WHITE);
            user_show_data(30, 10, "TEMP  :", temperature);
            user_show_data(30, 30, "ACC_X :", acc_data[0]);
            user_show_data(30, 50, "ACC_Y :", acc_data[1]);
            user_show_data(30, 70, "ACC_Z :", acc_data[2]);
            user_show_data(30, 90, "GYRO_X:", gyro_data[0]); 
            user_show_data(30, 110, "GYRO_Y:", gyro_data[1]);
            user_show_data(30, 130, "GYRO_Z:", gyro_data[2]); 
            
            printf("ACC_X:%d\r\n", acc_data[0]);
            printf("ACC_Y:%d\r\n", acc_data[1]);
            printf("ACC_Y:%d\r\n", acc_data[2]);
            printf("GYRO_X:%d\r\n", gyro_data[0]);
            printf("GYRO_Y:%d\r\n", gyro_data[1]);
            printf("GYRO_Z:%d\r\n", gyro_data[2]);
            lcd_draw_picture(0, 0, 320, 240, (uint16_t *)lcd_gram);
            t = 0;
        }
    }
}
