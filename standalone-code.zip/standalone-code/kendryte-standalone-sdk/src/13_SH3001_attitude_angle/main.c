/**
 ****************************************************************************************************
 * @file        main.c
 * @author      正点原子团队(ALIENTEK)
 * @version     V1.0
 * @date        2024-01-01
 * @brief       SH3001姿态解算 实验
 * @license     Copyright (c) 2020-2032, 广州市星翼电子科技有限公司
 ****************************************************************************************************
 * @attention
 *
 * 实验平台:正点原子 K210开发板
 * 在线视频:www.yuanzige.com
 * 技术论坛:www.openedv.com
 * 公司网址:www.alientek.com
 * 购买地址:openedv.taobao.com
 * 
 ****************************************************************************************************
 */

#include "sleep.h"
#include "gpiohs.h"
#include "sysctl.h"
#include "image_process.h"
#include "fpioa.h"
#include "uart.h"
#include "uarths.h"
#include "./BSP/SH3001/sh3001.h"
#include "./BSP/SH3001/imu.h"
#include "./BSP/IIC/iic.h"
#include "./BSP/LCD/lcdfont.h"
#include "./BSP/LCD/lcd.h"

/*****************************HARDWARE-PIN*********************************/
/* 硬件IO口，与原理图对应 */
#define PIN_UART_USB_RX         (4)
#define PIN_UART_USB_TX         (5)

/*****************************FUNC-GPIO************************************/
/* GPIO口的功能，绑定到硬件IO口 */
#define FUNC_UART_USB_RX       (FUNC_UARTHS_RX)
#define FUNC_UART_USB_TX       (FUNC_UARTHS_TX)

static uint16_t lcd_gram[320 * 240] __attribute__((aligned(32)));


/**
 * @brief       显示角度
 *  @note       以图片显示的方式更快  
 * @param       x, y : 坐标
 * @param       title: 标题
 * @param       angle: 角度
 * @retval      无
 */
void user_show_data(uint16_t x, uint16_t y, char * title, float angle)
{
    char buf[15];

    sprintf(buf,"%s%3.1fC", title, angle);          /* 格式化输出 */
    draw_fill_rectangle_image(lcd_gram, 320, x, y, x + 120, y + 16, WHITE);
    draw_string_rgb565_image(lcd_gram, 320, 240, x, y, buf, BLUE);
}

/**
 * @brief       USB串口发送1个字符
 * @param       c:要发送的字符
 * @retval      无 
 */
void usart1_send_char(const uint8_t *c, size_t len)
{
    uarths_send_data(c, len);
}

/**
 * @brief       传送数据给 ANO_TC匿名科创地面站v4.exe
 * @param       fun:功能字. 0XA0~0XAF
 * @param       data:数据缓存区,最多28字节!!
 * @param       len:data区有效数据个数
 * @retval      无 
 */
void usart1_niming_report(uint8_t fun, uint8_t *data, uint8_t len)
{
    uint8_t send_buf[32];
    uint8_t i;

    if (len > 28)
    {
        return;    /* 最多28字节数据 */
    }

    send_buf[len + 4] = 0;  /* 校验数置零 */
    send_buf[0] = 0XAA;     /* 帧头 */
    send_buf[1] = 0XAA;     /* 帧头 */
    send_buf[2] = fun;      /* 功能字 */
    send_buf[3] = len;      /* 数据长度 */

    for (i = 0; i < len; i++)
    {
        send_buf[4 + i] = data[i];             /* 复制数据 */
    }
    
    for (i = 0; i < len + 4; i++)
    {
        send_buf[len + 4] += send_buf[i];      /* 计算校验和 */
    }
    
    usart1_send_char((const uint8_t *)send_buf, (len + 5));         /* 发送数据到USB串口 */
}

/**
 * @brief       发送加速度传感器数据和陀螺仪数据
 * @param       aacx,aacy,aacz:x,y,z三个方向上面的加速度值
 * @param       gyrox,gyroy,gyroz:x,y,z三个方向上面的陀螺仪值
 * @retval      无 
 */
void sh3001_send_data(short aacx, short aacy, short aacz, short gyrox, short gyroy, short gyroz)
{
    uint8_t tbuf[18];
    tbuf[0] = (aacx >> 8) & 0XFF;
    tbuf[1] = aacx & 0XFF;
    tbuf[2] = (aacy >> 8) & 0XFF;
    tbuf[3] = aacy & 0XFF;
    tbuf[4] = (aacz >> 8) & 0XFF;
    tbuf[5] = aacz & 0XFF;
    tbuf[6] = (gyrox >> 8) & 0XFF;
    tbuf[7] = gyrox & 0XFF;
    tbuf[8] = (gyroy >> 8) & 0XFF;
    tbuf[9] = gyroy & 0XFF;
    tbuf[10] = (gyroz >> 8) & 0XFF;
    tbuf[11] = gyroz & 0XFF;
    tbuf[12]=0;  /* 因为开启MPL后,无法直接读取磁力计数据,所以这里直接屏蔽掉.用0替代. */
    tbuf[13]=0;
    tbuf[14]=0;
    tbuf[15]=0;
    tbuf[16]=0;
    tbuf[17]=0;
    usart1_niming_report(0X02, tbuf, 18);             /* 自定义帧,0X02 */
}

/**
 * @brief       通过串口1上报结算后的姿态数据给电脑
 * @param       roll:横滚角.单位0.1度。 -9000 -> 9000 对应 -90.00  ->  90.00度
 * @param       pitch:俯仰角.单位 0.1度。-18000 - 18000 对应 -180.00 -> 180.00 度
 * @param       yaw:航向角.单位为0.1度 -18000 -> 18000  对应 -180.00 -> 180.00 度
 * @param       prs:气压计高度,单位:cm
 * @param       fly_mode:飞行模式
 * @param       armed:锁定状态
 * @retval      无 
 */
void usart1_report_imu(short roll,short pitch,short yaw,int prs, uint8_t fly_mode, uint8_t armed)
{
    uint8_t tbuf[12];
  
    tbuf[0] = (roll >> 8) & 0XFF;
    tbuf[1] = roll & 0XFF;
    tbuf[2] = (pitch >> 8) & 0XFF;
    tbuf[3] = pitch & 0XFF;
    tbuf[4] = (yaw >> 8) & 0XFF;
    tbuf[5] = yaw & 0XFF;
    tbuf[6] = (prs >> 24) & 0XFF;
    tbuf[7] = (prs >> 16) & 0XFF;
    tbuf[8] = (prs >> 8) & 0XFF;
    tbuf[9] = prs & 0XFF;
    tbuf[10] = fly_mode;
    tbuf[11] = armed;
    usart1_niming_report(0X01, tbuf, 12); /* 状态帧,0X01 */
} 

/**
 * @brief       硬件初始化，绑定GPIO口
 * @param       无
 * @retval      无 
 */
void hardware_init(void)
{
    fpioa_set_function(PIN_UART_USB_RX, FUNC_UART_USB_RX);
    fpioa_set_function(PIN_UART_USB_TX, FUNC_UART_USB_TX);
}

int main(void)
{
    uint8_t t = 0;
    float temperature;                          /* 温度值 */
    short acc_data[3];                          /* 加速度传感器原始数据 */
    short gyro_data[3];                         /* 陀螺仪原始数据 */
    eulerian_angles_t e_angles;

    sysctl_pll_set_freq(SYSCTL_PLL0, 800000000);
    sysctl_pll_set_freq(SYSCTL_PLL1, 400000000);
    sysctl_pll_set_freq(SYSCTL_PLL2, 45158400);
    sysctl_set_power_mode(SYSCTL_POWER_BANK6, SYSCTL_POWER_V18);
    sysctl_set_power_mode(SYSCTL_POWER_BANK7, SYSCTL_POWER_V18);
    sysctl_set_spi0_dvp_data(1);

    lcd_init();
    lcd_set_direction(DIR_YX_LRUD);

    /* 硬件引脚初始化 */
    hardware_init();

    uarths_init();
    uarths_config(500000,UARTHS_STOP_1);

    /* 初始化 IMU */
    while (sh3001_init())     /* 检测不到SH3001 */
    {
        msleep(10);
    }
    msleep(500);

    imu_init();   
    for (size_t i = 0; i < 320 * 240; i++)
    {
        lcd_gram[i] = 0xFFFF;
    }
                              
    while (1)
    {
        usleep(3200);    /* 调节延时，矫正YAW角 */
        t++;
        
        sh3001_get_imu_compdata(acc_data, gyro_data);

        /* 数据校准 */
        imu_data_calibration(&gyro_data[0], &gyro_data[1], &gyro_data[2],
                            &acc_data[0],  &acc_data[1],  &acc_data[2]);

        /* 获取欧拉角 */
        e_angles = imu_get_eulerian_angles(gyro_data[0], gyro_data[1], gyro_data[2],
                                        acc_data[0],  acc_data[1],  acc_data[2]);

        sh3001_send_data(acc_data[0], acc_data[1], acc_data[2], gyro_data[0], gyro_data[1], gyro_data[2]);  /* 发送加速度+陀螺仪原始数据 */
        usart1_report_imu((int)(e_angles.roll * 100), (int)(e_angles.pitch * 100), (int)(e_angles.yaw * 100), 0, 0, 0);

        if (t == 50)
        {        
            temperature = sh3001_get_tempdata();    /* 读取温度值 */
            // printf("temp=%.2f\n", temperature);
            user_show_data(30, 30, "Temp :", temperature);
            user_show_data(30, 50, "Pitch:", e_angles.pitch);
            user_show_data(30, 70, "Roll :", e_angles.roll);
            user_show_data(30, 90, "Yaw  :", e_angles.yaw); 
            
            // printf("\r\nPITCH:%f\r\n", e_angles.pitch);
            // printf("ROLL:%f\r\n", e_angles.roll);
            // printf("YAW:%f\r\n", e_angles.yaw);
            lcd_draw_picture(0, 0, 320, 240, (uint16_t *)lcd_gram);
            t = 0;
        }
    }
}
