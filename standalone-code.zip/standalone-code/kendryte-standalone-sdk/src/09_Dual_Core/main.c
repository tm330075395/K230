/**
 ****************************************************************************************************
 * @file        main.c
 * @author      正点原子团队(ALIENTEK)
 * @version     V1.0
 * @date        2024-01-01
 * @brief       双核运行 实验
 * @license     Copyright (c) 2020-2032, 广州市星翼电子科技有限公司
 ****************************************************************************************************
 * @attention
 *
 * 实验平台:正点原子 K210开发板
 * 在线视频:www.yuanzige.com
 * 技术论坛:www.openedv.com
 * 公司网址:www.alientek.com
 * 购买地址:openedv.taobao.com
 ****************************************************************************************************
 */

#include <stdio.h>
#include "bsp.h"
#include "sleep.h"
#include "sysctl.h"

/**
 * @brief       核心1主函数
 *  @note       开启核心1，并进入while（1）循环，并打印不同数据
 * @param       ctx：回调的参数，没有设置为NULL
 * @retval      无
 */
int core1_main(void *ctx)
{
    int state = 1;
    uint64_t core = current_coreid();         /* 获取当前运行的CPU核心编号 */
    printf("Core %ld say: Hello world\n", core);

    while(1)
    {
        msleep(500);
        if (state = !state)
        {
            printf("Core %ld is running too!\n", core);
        }
        else
        {
            printf("Core %ld is running faster!\n", core);
        }
    }
}

int main(void)
{
    uint64_t core = current_coreid();          /* 获取当前运行的CPU核心编号 */
    printf("Core %ld say: ATK-DNK210\n", core);
    register_core1(core1_main, NULL);          /* 注册核心1，并启动核心1 */

    while(1)
    {
        sleep(1);
        printf("Core %ld is running!\n", core);
    }
}
