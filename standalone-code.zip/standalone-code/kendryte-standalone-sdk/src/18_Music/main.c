/**
 ****************************************************************************************************
 * @file        main.c
 * @author      正点原子团队(ALIENTEK)
 * @version     V1.0
 * @date        2024-01-01
 * @brief       音频播放 实验
 * @license     Copyright (c) 2020-2032, 广州市星翼电子科技有限公司
 ****************************************************************************************************
 * @attention
 *
 * 实验平台:正点原子 K210开发板
 * 在线视频:www.yuanzige.com
 * 技术论坛:www.openedv.com
 * 公司网址:www.alientek.com
 * 购买地址:openedv.taobao.com
 * 
 ****************************************************************************************************
 */

#include <stddef.h>
#include <stdio.h>
#include "dmac.h"
#include "sysctl.h"
#include "sleep.h"
#include "wavplay.h" 
#include "./BSP/SDCARD/sdcard.h"
#include "./BSP/FATFS/ff.h"
#include "./BSP/SPEAKER/speaker.h"
#include "./BSP/LCD/lcd.h"

char *pname = {"0:MUSIC/play.wav"};  

int main(void)
{
    FRESULT res;
    FATFS fs;

    sysctl_pll_set_freq(SYSCTL_PLL0, 800000000);
    sysctl_pll_set_freq(SYSCTL_PLL1, 400000000);
    sysctl_pll_set_freq(SYSCTL_PLL2, 45158400);
    sysctl_set_power_mode(SYSCTL_POWER_BANK6, SYSCTL_POWER_V18);
    sysctl_set_power_mode(SYSCTL_POWER_BANK7, SYSCTL_POWER_V18);
    sysctl_set_spi0_dvp_data(1);

    speaker_i2s_hardware_init(); /* 扬声器接口初始化 */
    plic_init();         /* 初始化中断 */
    sysctl_enable_irq(); /* 使能全局中断 */
    dmac_init();         /* 初始化dmac */
    lcd_init();          /* 初始化LCD */
    lcd_set_direction(DIR_YX_LRUD);

    lcd_draw_string(10, 10, "MUSIC ", RED); 

    /* 初始化SD卡*/
    if (sd_init() != 0)
    {
        printf("SD card initialization failed!\n");
        while (1);
    }
    printf("SD card initialization succeed!\n");

    /* 文件系统挂载SD卡 */
    res = f_mount(&fs, _T("0:"), 1);
    if (res != FR_OK)
    {
        printf("SD card mount failed! Error code: %d\n", res);
        while (1);
    }
    printf("SD card mount succeed!\n");

    wav_play_song((uint8_t *)pname);  /* 播放音频play.wav */
    lcd_draw_string(10, 50, "End of play ", BLUE); 
    while (1)
    {

    }
}

