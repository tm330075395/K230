/**
 ****************************************************************************************************
 * @file        speaker.h
 * @author      正点原子团队(ALIENTEK)
 * @version     V1.0
 * @date        2024-01-01
 * @brief       扬声器接口 驱动代码
 * @license     Copyright (c) 2020-2032, 广州市星翼电子科技有限公司
 ****************************************************************************************************
 * @attention
 * 
 * 实验平台:正点原子 K210开发板
 * 在线视频:www.yuanzige.com
 * 技术论坛:www.openedv.com
 * 公司网址:www.alientek.com
 * 购买地址:openedv.taobao.com
 *
 ****************************************************************************************************
 */

#ifndef __SPEAKER_H
#define __SPEAKER_H

#include <stdio.h>
#include "gpio.h"

/*****************************HARDWARE-PIN*********************************/
/* 硬件IO口，与原理图对应 */
#define PIN_SPK_CTRL           (21)

#define PIN_SPK_WS             (33)
#define PIN_SPK_DATA           (31)
#define PIN_SPK_BCK            (32)

/*****************************SOFTWARE-GPIO********************************/
/* 软件GPIO口，与程序对应 */
#define SPK_CTRL_GPIONUM       (0)

/*****************************FUNC-GPIO************************************/
/* GPIO口的功能，绑定到硬件IO口 */
#define FUNC_SPK_CTRL          (FUNC_GPIO0 + SPK_CTRL_GPIONUM)

#define FUNC_SPK_WS            FUNC_I2S0_WS
#define FUNC_SPK_DATA          FUNC_I2S0_OUT_D0
#define FUNC_SPK_BCK           FUNC_I2S0_SCLK

/* 函数声明 */
void speaker_i2s_hardware_init(void);     /* 初始化扬声器接口 */

#endif
