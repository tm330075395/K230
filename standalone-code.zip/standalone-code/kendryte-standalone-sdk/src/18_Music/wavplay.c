/**
 ****************************************************************************************************
 * @file        wavplay.c
 * @author      正点原子团队(ALIENTEK)
 * @version     V1.0
 * @date        2024-01-01
 * @brief       wav解码 代码
 * @license     Copyright (c) 2020-2032, 广州市星翼电子科技有限公司
 ****************************************************************************************************
 * @attention
 *
 * 实验平台:正点原子 K210开发板
 * 在线视频:www.yuanzige.com
 * 技术论坛:www.openedv.com
 * 公司网址:www.alientek.com
 * 购买地址:openedv.taobao.com
 *
 ****************************************************************************************************
 */

#include "sysctl.h"
#include <stddef.h>
#include <stdio.h>
#include "wavplay.h" 
#include "sleep.h" 
#include "iomem.h"
#include "i2s.h"
#include "ff.h"
#include "image_process.h"
#include "./BSP/LCD/lcd.h"

__audiodev g_audiodev;                 /* 音乐播放控制器 */
__wavctrl wavctrl;                     /* WAV控制结构体 */
volatile uint8_t wavbuf1f1nish = 0;    /* i2s传输完成标志 0,未填充，1，buf2填充完成*/
volatile uint8_t wavbuf2f1nish = 0;    /* i2s传输完成标志 0,未填充，1，buf2填充完成*/
volatile uint8_t wavplay = 0;          /* i2sbufx指示标志 0,播放buf1，1，播放buf2*/
uint32_t fillnum;                      /* 存储读取的音频文件大小 */
uint16_t lcd_gram[320 * 16] __attribute__((aligned(32)));


/**
 * @brief       WAV解析初始化
 * @param       fname : 文件路径+文件名
 * @param       wavx  : 信息存放结构体指针
 * @retval      0,打开文件成功
 *              1,打开文件失败
 *              2,非WAV文件
 *              3,DATA区域未找到
 */
uint8_t wav_decode_init(uint8_t* fname, __wavctrl* wavx)
{
    FIL *ftemp;
    uint8_t *buf; 
    uint32_t br = 0;
    uint8_t res = 0;

    ChunkRIFF *riff;
    ChunkFMT *fmt;
    ChunkFACT *fact;
    ChunkDATA *data;
    
    ftemp = (FIL*)iomem_malloc(sizeof(FIL));
    buf = iomem_malloc(512);

    if (ftemp && buf)    /* 内存申请成功 */
    {
        res = f_open(ftemp, (TCHAR*)fname, FA_READ);    /* 打开文件 */
        if (res==FR_OK)
        {
            f_read(ftemp, buf, 512, &br);               /* 读取512字节在数据 */
            riff = (ChunkRIFF *)buf;                    /* 获取RIFF块 */
            if (riff->Format == 0X45564157)             /* 是WAV文件 */
            {
                fmt = (ChunkFMT *)(buf + 12);           /* 获取FMT块 */
                fact = (ChunkFACT *)(buf + 12 + 8 + fmt->ChunkSize);                    /* 读取FACT块 */

                if (fact->ChunkID == 0X74636166 || fact->ChunkID == 0X5453494C)
                {
                    wavx->datastart = 12 + 8 + fmt->ChunkSize + 8 + fact->ChunkSize;    /* 具有fact/LIST块的时候(未测试) */
                }
                else
                {
                    wavx->datastart = 12 + 8 + fmt->ChunkSize;
                }

                data = (ChunkDATA *)(buf + wavx->datastart);    /* 读取DATA块 */

                if (data->ChunkID == 0X61746164)                /* 解析成功! */
                {
                    wavx->audioformat = fmt->AudioFormat;       /* 音频格式 */
                    wavx->nchannels = fmt->NumOfChannels;       /* 通道数 */
                    wavx->samplerate = fmt->SampleRate;         /* 采样率 */
                    wavx->bitrate = fmt->ByteRate * 8;          /* 得到位速 */
                    wavx->blockalign = fmt->BlockAlign;         /* 块对齐 */
                    wavx->bps = fmt->BitsPerSample;             /* 位数,16/24/32位 */
                    
                    wavx->datasize = data->ChunkSize;           /* 数据块大小 */
                    wavx->datastart = wavx->datastart + 8;      /* 数据流开始的地方. */
                     
                    printf("wavx->audioformat:%d\r\n", wavx->audioformat);
                    printf("wavx->nchannels:%d\r\n", wavx->nchannels);
                    printf("wavx->samplerate:%d\r\n", wavx->samplerate);
                    printf("wavx->bitrate:%d\r\n", wavx->bitrate);
                    printf("wavx->blockalign:%d\r\n", wavx->blockalign);
                    printf("wavx->bps:%d\r\n", wavx->bps);
                    printf("wavx->datasize:%d\r\n", wavx->datasize);
                    printf("wavx->datastart:%d\r\n", wavx->datastart);  
                }
                else
                {
                    res = 3;    /* data区域未找到. */
                }
            }
            else
            {
                res = 2;        /* 非wav文件 */
            }
        }
        else
        {
            res = 1;            /* 打开文件错误 */
        }
    }

    f_close(ftemp);             /* 关闭文件 */
    printf("f_clase\n");
    iomem_free(ftemp);          /* 释放内存 */
    iomem_free(buf); 

    return 0;
}

/**
 * @brief       填充buf
 * @param       buf  : 填充区
 * @param       size : 填充数据量
 * @param       bits : 位数(16)
 * @retval      读取到的数据长度
 */
uint32_t wav_buffill(uint8_t *buf, uint16_t size, uint8_t bits)
{
    uint32_t bread;
    uint16_t i;

    if (bits == 16)  
    {
        f_read(g_audiodev.file, buf, size, (UINT*)&bread);                /* 16bit音频,直接读取数据 */
        if (bread < size)           /* 不够数据了,补充0 */
        {
            for(i = bread; i < size - bread; i++)
            {
                buf[i] = 0;
            }
        }
    }

    // else if (bits == 24)                 /* 24bit音频,需要处理一下 */
    // {
    //     readlen = (size / 4) * 3;   /* 此次要读取的字节数 */
    //     f_read(g_audiodev.file, g_audiodev.tbuf, readlen, (UINT*)&bread);   /* 读取数据 */
    //     p = g_audiodev.tbuf;

    //     for (i = 0; i < size;)
    //     {
    //         buf[i++] = p[1];
    //         buf[i] = p[2];
    //         i += 2;
    //         buf[i++] = p[0];
    //         p += 3;
    //     }

    //     bread = (bread * 4) / 3;    /* 填充后的大小. */
    // }
    
    return bread;
}

/**
 * @brief       音频播放的buf填充
 * @param       无
 * @retval      无
 */
void wav_play_buffill(void) 
{    
    if(wavbuf1f1nish == 0 && wavplay == 1)
    {  
        fillnum = wav_buffill(g_audiodev.i2sbuf1, WAV_I2S_TX_DMA_BUFSIZE, wavctrl.bps);   /* 填充buf1 */
        wavbuf1f1nish = 1;
    }
    else if (wavbuf2f1nish == 0 && wavplay == 0) 
    {
        fillnum = wav_buffill(g_audiodev.i2sbuf2, WAV_I2S_TX_DMA_BUFSIZE, wavctrl.bps);   /* 填充buf1 */
        wavbuf2f1nish = 1;
    }
}

/**
 * @brief       I2S音频文件传输
 * @param       device_num : I2S总线号
 * @param       channel_num : DM通道号
 * @param       buf : PCM数据
 * @param       buf_len : 发送德数据长度
 * @param       frame : 单次发送的声音数据量
 * @param       bits_per_sample : 位宽
 * @param       track_num : 声道数
 * @retval      无
 */
void i2s_pcm_play(i2s_device_number_t device_num, dmac_channel_number_t channel_num,
              const uint8_t *buf, size_t buf_len, size_t frame, size_t bits_per_sample, uint8_t track_num)
{
    const uint8_t *trans_buf;
    uint32_t i;
    size_t sample_cnt = buf_len / (bits_per_sample / 8) / track_num;
    size_t frame_cnt = sample_cnt / frame;
    size_t frame_remain = sample_cnt % frame;
    i2s_set_dma_divide_16(device_num, 0);

    if(bits_per_sample == 16 && track_num == 2)
    {
        i2s_set_dma_divide_16(device_num, 1);
        for(i = 0; i < frame_cnt; i++)
        {
            trans_buf = buf + i * frame * (bits_per_sample / 8) * track_num;  /* 按声音数量发送，一个声音大小和位数，声道相关 */
            i2s_send_data_dma(device_num, trans_buf, frame, channel_num);
            wav_play_buffill();
        }
        if(frame_remain)
        {
            trans_buf = buf + frame_cnt * frame * (bits_per_sample / 8) * track_num;
            i2s_send_data_dma(device_num, trans_buf, frame_remain, channel_num);
            wav_play_buffill();
        }
    }
}

/**
 * @brief       获取当前播放时间
 * @param       fname : 文件指针
 * @param       wavx  : wavx播放控制器
 * @retval      无
 */
void wav_get_curtime(FIL *fx, __wavctrl *wavx)
{
    long long fpos;

    wavx->totsec = wavx->datasize / (wavx->bitrate / 8);    /* 歌曲总长度(单位:秒) */
    fpos = fx->fptr-wavx->datastart;                        /* 得到当前文件播放到的地方 */
    wavx->cursec = fpos*wavx->totsec / wavx->datasize;      /* 当前播放到第多少秒了? */
}

/**
 * @brief       显示播放时间,比特率 信息
 * @param       totsec : 音频文件总时间长度
 * @param       cursec : 当前播放时间
 * @retval      无
 */
void audio_msg_show(uint32_t totsec, uint32_t cursec)
{
    char datashow[35];
    static uint16_t playtime = 0XFFFF;  /* 放时间标记 */
    
    if (playtime != cursec)             /* 需要更新显示时间 */
    {
        playtime = cursec;
        
        /* 显示播放时间 */
        sprintf((char *)datashow, "Play time:%02d:%02d/%02d:%02d", playtime / 60, playtime % 60, totsec / 60, totsec % 60);
        // lcd_draw_fill_rectangle(10 + 8 * 11, 30, 10 + 8 * 15, 30 + 16, WHITE);
        // lcd_draw_string(10, 30, (char *)datashow, BLUE);         /* 显示SD卡容量 */
        /* 显示字符的形式实在太慢了，会导致播放卡顿，所以用画图的形式显示 */
        for (size_t i = 0; i < 320 * 16; i++)
        {
            lcd_gram[i] = 0xFFFF;
        }
        draw_string_rgb565_image(lcd_gram, 320, 240, 10, 0, datashow, BLUE);
        lcd_draw_picture(0, 30, 320, 16, (uint16_t *)lcd_gram);   
    }
}

/**
 * @brief       播放某个wav文件
 * @param       fname : 文件路径+文件名
 * @retval      KEY0_PRES,错误
 *              KEY1_PRES,打开文件失败
 *              其他,非WAV文件
 */
uint8_t wav_play_song(uint8_t* fname)
{
    uint8_t res;  
    
    g_audiodev.file = (FIL*)iomem_malloc(sizeof(FIL));
    g_audiodev.i2sbuf1 = iomem_malloc(WAV_I2S_TX_DMA_BUFSIZE);
    g_audiodev.i2sbuf2 = iomem_malloc(WAV_I2S_TX_DMA_BUFSIZE);
    g_audiodev.tbuf = iomem_malloc(WAV_I2S_TX_DMA_BUFSIZE);
    
    if (g_audiodev.file && g_audiodev.i2sbuf1 && g_audiodev.i2sbuf2 && g_audiodev.tbuf)
    { 
        res = wav_decode_init(fname, &wavctrl); /* 得到文件的信息 */
        if (res == 0)   /* 解析文件成功 */
        {
            /* 初始化I2S，第三个参数为设置通道掩码，通道0:0x03,通道1：0x0C,通道2：0x30,通道3:0xC0 */
            i2s_init(I2S_DEVICE_0, I2S_TRANSMITTER, 0x03);
            if (wavctrl.bps == 16)
            {
                /* 设置I2S发送数据的通道参数 */
                i2s_tx_channel_config(
                    I2S_DEVICE_0, /* I2S设备号*/
                    I2S_CHANNEL_0, /* I2S通道 */
                    RESOLUTION_16_BIT, /* 接收数据位数 */
                    SCLK_CYCLES_32, /* 单个数据时钟数 */
                    TRIGGER_LEVEL_4, /* DMA触发时FIFO深度 */
                    STANDARD_MODE); /* 工作模式 */
            }
            // else if (wavctrl.bps == 24) /* 暂不支持 */
            // {

            // }

            res = f_open(g_audiodev.file, (TCHAR*)fname, FA_READ);    /* 打开文件 */ 
            if (res == 0)
            {
                f_lseek(g_audiodev.file, wavctrl.datastart);          /* 跳过文件头 */
                fillnum = wav_buffill(g_audiodev.i2sbuf1, WAV_I2S_TX_DMA_BUFSIZE, wavctrl.bps);
                // fillnum = wav_buffill(g_audiodev.i2sbuf2, WAV_I2S_TX_DMA_BUFSIZE, wavctrl.bps);
                wavbuf1f1nish = 1;
                wavbuf2f1nish = 0;
                wavplay = 0;
                while (1)
                {
                    if (wavplay)
                    {
                        i2s_pcm_play(
                        I2S_DEVICE_0, /* I2S设备号 */
                        DMAC_CHANNEL1, /* DMA通道号 */ 
                        (uint8_t *)g_audiodev.i2sbuf2, /* 播放的PCM数据 */
                        WAV_I2S_TX_DMA_BUFSIZE, /* PCM数据的长度 */
                        1024, /* 单次发送数量 */
                        16, /* 单次采样位宽 */
                        2); /* 声道数 */
                        wavbuf2f1nish = 0;
                        wavplay = 0;
                    }
                    else
                    {
                        i2s_pcm_play(
                        I2S_DEVICE_0, /* I2S设备号 */
                        DMAC_CHANNEL1, /* DMA通道号 */ 
                        (uint8_t *)g_audiodev.i2sbuf1, /* 播放的PCM数据 */
                        WAV_I2S_TX_DMA_BUFSIZE, /* PCM数据的长度 */
                        1024, /* 单次发送数量 */
                        16, /* 单次采样位宽 */
                        2); /* 声道数 */
                        wavbuf1f1nish = 0;
                        wavplay = 1;
                    }
                    if (fillnum != WAV_I2S_TX_DMA_BUFSIZE)    /* 文件剩余不足，播放完结束*/
                    {
                        dmac_wait_done(DMAC_CHANNEL0);
                        printf("play end\n");
                        break;
                    } 
                    wav_get_curtime(g_audiodev.file, &wavctrl);   /* 得到总时间和当前播放的时间 */
                    audio_msg_show(wavctrl.totsec, wavctrl.cursec);
                }
            }
            else
            {
                res = 0XFF;
            }
        }
        else
        {
            res = 0XFF;
        }
    }
    else
    {
        res = 0XFF;
    }
    iomem_free(g_audiodev.tbuf);      /* 释放内存 */
    iomem_free(g_audiodev.i2sbuf1);   /* 释放内存 */
    iomem_free(g_audiodev.i2sbuf2);   /* 释放内存 */
    iomem_free(g_audiodev.file);      /* 释放内存 */
    
    return res;
}

