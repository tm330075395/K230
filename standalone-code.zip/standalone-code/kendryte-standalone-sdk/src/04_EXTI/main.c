/**
 ****************************************************************************************************
 * @file        main.c
 * @author      正点原子团队(ALIENTEK)
 * @version     V1.0
 * @date        2024-01-01
 * @brief       按键中断 实验
 * @license     Copyright (c) 2020-2032, 广州市星翼电子科技有限公司
 ****************************************************************************************************
 * @attention
 *
 * 实验平台:正点原子 K210开发板
 * 在线视频:www.yuanzige.com
 * 技术论坛:www.openedv.com
 * 公司网址:www.alientek.com
 * 购买地址:openedv.taobao.com
 ****************************************************************************************************
 */

#include <stdio.h>
#include <unistd.h>
#include <sleep.h>
#include "./BSP/EXTI/exti.h"
#include "./BSP/LED/led.h"

int main(void)
{
    led_init();     /* LED初始化 */
    exti_init();    /* 外部中断初始化 */

    while (1)
    {
        msleep(10);
    }
}
