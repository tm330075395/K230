/**
 ****************************************************************************************************
 * @file        key.c
 * @author      正点原子团队(ALIENTEK)
 * @version     V1.0
 * @date        2024-01-01
 * @brief       外部中断 驱动代码
 * @license     Copyright (c) 2020-2032, 广州市星翼电子科技有限公司
 ****************************************************************************************************
 * @attention
 *
 * 实验平台:正点原子 K210开发板
 * 在线视频:www.yuanzige.com
 * 技术论坛:www.openedv.com
 * 公司网址:www.alientek.com
 * 购买地址:openedv.taobao.com
 *
 ****************************************************************************************************
 */

#include "exti.h"
#include "sleep.h"
#include "fpioa.h"
#include "sysctl.h"
#include "../LED/led.h"


int gpiohs_key0_exti_cb(void *ctx)
{
    LEDR(1);   /* 红灯灭 */
    LEDB(0);   /* 蓝灯亮 */
    sleep(1);  /* 延时1秒 */
    LEDR(0);   /* 红灯亮 */
    LEDB(1);   /* 蓝灯灭 */
    sleep(1);  /* 延时1秒 */
    return 0;
}

/**
 * @brief       按键初始化函数
 * @param       无
 * @retval      无
 */
void exti_init(void)
{
    /* 初始化中断，使能全局中断*/
    plic_init();
    sysctl_enable_irq();

    fpioa_set_function(PIN_KEY_EXTI, FUNC_KEY0_EXTI);

    gpiohs_set_drive_mode(EXTI_GPIONUM, GPIO_DM_INPUT_PULL_UP);  /*输入上拉*/

    gpiohs_set_pin_edge(EXTI_GPIONUM, GPIO_PE_FALLING);          /* 设置为下降沿触发 */
    gpiohs_irq_register(EXTI_GPIONUM, 4, gpiohs_key0_exti_cb, NULL); /* 注册中断，绑定按键 */
}






