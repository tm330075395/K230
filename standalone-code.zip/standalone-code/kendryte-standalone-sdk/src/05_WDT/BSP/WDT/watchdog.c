/**
 ****************************************************************************************************
 * @file        watchdog.c
 * @author      正点原子团队(ALIENTEK)
 * @version     V1.0
 * @date        2024-01-01
 * @brief       看门狗定时器 驱动代码
 * @license     Copyright (c) 2020-2032, 广州市星翼电子科技有限公司
 ****************************************************************************************************
 * @attention
 * 
 * 实验平台:正点原子 K210开发板
 * 在线视频:www.yuanzige.com
 * 技术论坛:www.openedv.com
 * 公司网址:www.alientek.com
 * 购买地址:openedv.taobao.com
 *
 ****************************************************************************************************
 */

#include "watchdog.h"
#include "sysctl.h"
#include "wdt.h"

/**
 * @brief   看门狗中断回调
 * @param   ctx: 回调参数
 * @retval  无
 */
int wdt0_irq_cb(void *ctx)
{
    #if WDT_TIMEOUT_REBOOT
    printf("%s:The system will reboot soon!\n", __func__);
    while(1);
    #else
    printf("%s:The system is busy but not reboot!\n", __func__);
    wdt_clear_interrupt(WDT_DEVICE_0);
    #endif
    return 0;
}

/**
 * @brief   初始化看门狗定时器
 * @param   无
 * @retval  无
 */
void watchdog_init(void)
{
    /* 系统中断初始化 */
    plic_init();
    sysctl_enable_irq();

    /* 启动看门狗，设置超时时间为2秒后调用中断函数wdt0_irq_cb */
    int timeout = wdt_init(WDT_DEVICE_0, 2000, wdt0_irq_cb, NULL);

    /* 打印看门狗实际超时的时间 */
    printf("wdt timeout is %d ms!\n", timeout);
}
