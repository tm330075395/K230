/**
 ****************************************************************************************************
 * @file        watchdog.h
 * @author      正点原子团队(ALIENTEK)
 * @version     V1.0
 * @date        2024-01-01
 * @brief       看门狗定时器 驱动代码
 * @license     Copyright (c) 2020-2032, 广州市星翼电子科技有限公司
 ****************************************************************************************************
 * @attention
 * 
 * 实验平台:正点原子 K210开发板
 * 在线视频:www.yuanzige.com
 * 技术论坛:www.openedv.com
 * 公司网址:www.alientek.com
 * 购买地址:openedv.taobao.com
 *
 ****************************************************************************************************
 */

#ifndef __WATCHDOG_H
#define __WATCHDOG_H

#include <stdio.h>
#include "wdt.h"

/*              
* 默认WDT_TIMEOUT_REBOOT为1，看门狗如果没有在设置的时间内feed，则超时后重启系统。
* 如果修改WDT_TIMEOUT_REBOOT为0，则看门狗超时后只会串口发信息提示超时，不会重启。
*/
#define WDT_TIMEOUT_REBOOT    1

/* 函数声明 */
void watchdog_init(void);     /* 初始化看门狗 */

#endif
