/**
 ****************************************************************************************************
 * @file        main.c
 * @author      正点原子团队(ALIENTEK)
 * @version     V1.0
 * @date        2024-01-01
 * @brief       看门狗定时器 实验
 * @license     Copyright (c) 2020-2032, 广州市星翼电子科技有限公司
 ****************************************************************************************************
 * @attention
 *
 * 实验平台:正点原子 K210开发板
 * 在线视频:www.yuanzige.com
 * 技术论坛:www.openedv.com
 * 公司网址:www.alientek.com
 * 购买地址:openedv.taobao.com
 ****************************************************************************************************
 */
#include <stdio.h>
#include <unistd.h>
#include "sleep.h"
#include "wdt.h"
#include "sysctl.h"
#include "./BSP/KEY/key.h"
#include "./BSP/WDT/watchdog.h"

int main(void)
{
    uint8_t key;
    key_init();      /* 按键初始化 */
    watchdog_init(); /* 看门狗定时器初始化 */

    /* 打印系统启动信息 */
    printf("system start!\n");
    /* 记录feed的次数 */
    int feed_times  = 0;
    
    while(feed_times < 5)
    {
        key = key_scan(0);                  /* 得到键值 */
        if (key == KEY0_PRES)
        {
            feed_times ++;
            /* 打印feed的次数 */
            printf("Feed WDT0 %d times!\n", feed_times);
            /* 重置看门狗的计时器，重新开始计时 */
            wdt_feed(WDT_DEVICE_0);
        }
        else msleep(1);
    }
    wdt_stop(WDT_DEVICE_0); /* 停止看门狗 */
}

