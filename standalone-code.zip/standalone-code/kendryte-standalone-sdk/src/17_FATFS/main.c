/**
 ****************************************************************************************************
 * @file        main.c
 * @author      正点原子团队(ALIENTEK)
 * @version     V1.0
 * @date        2024-01-01
 * @brief       FATFS 实验
 * @license     Copyright (c) 2020-2032, 广州市星翼电子科技有限公司
 ****************************************************************************************************
 * @attention
 *
 * 实验平台:正点原子 K210开发板
 * 在线视频:www.yuanzige.com
 * 技术论坛:www.openedv.com
 * 公司网址:www.alientek.com
 * 购买地址:openedv.taobao.com
 * 
 ****************************************************************************************************
 */

#include <stddef.h>
#include <stdio.h>
#include "iomem.h"
#include "sysctl.h"
#include "./BSP/SDCARD/sdcard.h"
#include "./BSP/FATFS/ff.h"
#include "./BSP/LCD/lcd.h"


int main(void)
{
    FRESULT res;
    FATFS fs;
    DIR dir;
    FILINFO info;

    sysctl_pll_set_freq(SYSCTL_PLL0, 800000000);
    sysctl_pll_set_freq(SYSCTL_PLL1, 400000000);
    sysctl_pll_set_freq(SYSCTL_PLL2, 45158400);
    sysctl_set_power_mode(SYSCTL_POWER_BANK6, SYSCTL_POWER_V18);
    sysctl_set_power_mode(SYSCTL_POWER_BANK7, SYSCTL_POWER_V18);
    sysctl_set_spi0_dvp_data(1);

    lcd_init();                     /* 初始化LCD */
    lcd_set_direction(DIR_YX_LRUD);

    /* 初始化SD卡 */
    if (sd_init() != 0)
    {
        printf("SD card initialization failed!\n");
        while (1);
    }
    printf("SD card initialization succeed!\n");
    lcd_draw_string(10, 10, "SD card initialization succeed!", BLUE); /* 显示提示信息 */
    /* 文件系统挂载SD卡 */
    res = f_mount(&fs, _T("/SD"), 1);
    if (res != FR_OK)
    {
        printf("SD card mount failed! Error code: %d\n", res);
        while (1);
    }
    printf("SD card mount succeed!\n");
    lcd_draw_string(10, 30, "SD card mount succeed!", BLUE);         /* 显示提示信息 */


    /* 打开SD卡根目录文件夹 */
    res = f_opendir(&dir, _T("/SD"));
    if (res != FR_OK)
    {
        printf("SD card root folder open failed! Error code: %d\n", res);
        while (1);
    }
    printf("SD card root folder open succeed!\n");
    lcd_draw_string(10, 50, "SD card root folder open succeed!", BLUE); /* 显示提示信息 */

    /* 读取SD卡根目录文件 */
    while (1)
    {
        res = f_readdir(&dir, &info);
        if (res != FR_OK)
        {
            printf("SD card root folder read failed! Error code: %d\n", res);
            while (1);
        }
        if (info.fname[0] == '\0')
        {
            break;
        }
        printf("\t%s\n", info.fname);
    }
    printf("SD card root folder read succeed!\n");
    lcd_draw_string(10, 70, "SD card root folder read succeed!", BLUE);         /* 显示提示信息 */

    /* 关闭SD卡根目录文件夹 */
    res = f_closedir(&dir);
    if (res != FR_OK)
    {
        printf("SD card root folder close failed! Error code: %d\n", res);
        while (1);
    }
    printf("SD card root folder close succeed!\n");

    /* 文件系统卸载SD卡 */
    res = f_unmount(_T("/SD"));
    if (res != FR_OK)
    {
        printf("SD card unmount failed! Error code: %d\n", res);
        while (1);
    }
    printf("SD card unmount succeed!\n");
    lcd_draw_string(10, 90, "FATFS OK!", BLUE);         /* 显示提示信息 */

    while (1)
    {
        
    }
}
