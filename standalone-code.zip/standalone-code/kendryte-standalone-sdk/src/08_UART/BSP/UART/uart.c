/**
 ****************************************************************************************************
 * @file        uart.c
 * @author      正点原子团队(ALIENTEK)
 * @version     V1.0
 * @date        2024-01-01
 * @brief       UART 驱动代码
 * @license     Copyright (c) 2020-2032, 广州市星翼电子科技有限公司
 ****************************************************************************************************
 * @attention
 * 
 * 实验平台:正点原子 K210开发板
 * 在线视频:www.yuanzige.com
 * 技术论坛:www.openedv.com
 * 公司网址:www.alientek.com
 * 购买地址:openedv.taobao.com
 *
 ****************************************************************************************************
 */

#include "uart.h"
#include "sysctl.h"
#include "fpioa.h"
#include "plic.h"
#include "../../../../lib/drivers/include/uart.h"

/**
 * @brief   初始化USART
 * @param   baudrate：波特率
 * @retval  无
 */
void usart_init(uint32_t baudrate)
{
    fpioa_set_function(PIN_UART_USB_RX, FUNC_UART_USB_RX);
    fpioa_set_function(PIN_UART_USB_TX, FUNC_UART_USB_TX);
    /* 初始化串口号，设置波特率,8位数据格式，1个停止位，无奇偶校验位 */
    uart_init(UART_USB_NUM);
    uart_configure(UART_USB_NUM, baudrate, UART_BITWIDTH_8BIT, UART_STOP_1, UART_PARITY_NONE);
}
