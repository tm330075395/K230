/**
 ****************************************************************************************************
 * @file        main.c
 * @author      正点原子团队(ALIENTEK)
 * @version     V1.0
 * @date        2024-01-01
 * @brief       串口输出 实验
 * @license     Copyright (c) 2020-2032, 广州市星翼电子科技有限公司
 ****************************************************************************************************
 * @attention
 *
 * 实验平台:正点原子 K210开发板
 * 在线视频:www.yuanzige.com
 * 技术论坛:www.openedv.com
 * 公司网址:www.alientek.com
 * 购买地址:openedv.taobao.com
 ****************************************************************************************************
 */
#include <string.h>
#include <stdio.h>
#include <unistd.h>
#include "sleep.h"
#include "gpio.h"
#include "uart.h"
#include "./BSP/UART/uart.h"


char recvbut[200];

int main(void)
{
    uint16_t times = 0;
    uint8_t recvbut_len = 0;
    char *hello = {"正点原子K210 开发板\r\n"};

    usart_init(115200); /* 初始化UART */

    /* 开机发送正点原子K210 开发板 */
    uart_send_data(UART_USB_NUM, hello, strlen(hello));

    while (1)
    {

        /* 等待串口信息，并通过串口发送出去 */
        recvbut_len = uart_receive_data(UART_USB_NUM, recvbut, 200);
        if (recvbut_len != 0)
        {
            uart_send_data(UART_USB_NUM, recvbut, recvbut_len);
        }
        else
        {
            if ((times % 30000) == 0)
            {
                uart_send_data(UART_USB_NUM, hello, strlen(hello));
                times = 0;
            }
            times++;
            usleep(100);  
        }
    }
}
