/**
 ****************************************************************************************************
 * @file        bmp.h
 * @author      正点原子团队(ALIENTEK)
 * @version     V1.0
 * @date        2024-01-01
 * @brief       图片解码-bmp解码 代码
 * @license     Copyright (c) 2020-2032, 广州市星翼电子科技有限公司
 ****************************************************************************************************
 * @attention
 *
 * 实验平台:正点原子 K210开发板
 * 在线视频:www.yuanzige.com
 * 技术论坛:www.openedv.com
 * 公司网址:www.alientek.com
 * 购买地址:openedv.taobao.com
 *
 ****************************************************************************************************
 */

#ifndef __BMP_H
#define __BMP_H

#include "./BSP/FATFS/ff.h"


/******************************************************************************************/
/* 用户配置区 */
#define BMP_USE_MALLOC      1           /* 定义是否使用malloc,这里我们选择使用malloc */
#define BMP_DBUF_SIZE       2048        /* 定义bmp解码数组的大小(最少应为LCD宽度*3) */

#define PIC_FORMAT_ERR      0x27    /* 格式错误 */
#define PIC_SIZE_ERR        0x28    /* 图片尺寸错误 */
#define PIC_WINDOW_ERR      0x29    /* 窗口设定错误 */
#define PIC_MEM_ERR         0x11    /* 内存错误 */
/******************************************************************************************/
// #define __PACKED_STRUCT                        __packed struct

/* 图像信息 */
typedef struct
{
    uint16_t lcdwidth;      /* LCD的宽度 */
    uint16_t lcdheight;     /* LCD的高度 */
    uint32_t ImgWidth;      /* 图像的实际宽度和高度 */
    uint32_t ImgHeight;

    uint32_t Div_Fac;       /* 缩放系数 (扩大了8192倍的) */

    uint32_t S_Height;      /* 设定的高度和宽度 */
    uint32_t S_Width;

    uint32_t S_XOFF;        /* x轴和y轴的偏移量 */
    uint32_t S_YOFF;

    uint32_t staticx;       /* 当前显示到的ｘｙ坐标 */
    uint32_t staticy;
} _pic_info;

/* BMP信息头 */
typedef struct
{
    DWORD biSize ;           /* 说明BITMAPINFOHEADER结构所需要的字数。 */
    DWORD  biWidth ;             /* 说明图象的宽度，以象素为单位 */
    DWORD  biHeight ;            /* 说明图象的高度，以象素为单位 */
    WORD  biPlanes ;        /* 为目标设备说明位面数，其值将总是被设为1 */
    WORD  biBitCount ;      /* 说明比特数/象素，其值为1、4、8、16、24、或32 */
    DWORD biCompression ;    /* 说明图象数据压缩的类型。其值可以是下述值之一
                                 * BI_RGB      ：没有压缩
                                 * BI_RLE8     ：每个象素8比特的RLE压缩编码，压缩格式由2字节组成(重复象素计数和颜色索引) 
                                 * BI_RLE4     ：每个象素4比特的RLE压缩编码，压缩格式由2字节组成 
                                 * BI_BITFIELDS：每个象素的比特由指定的掩码决定 
                                 */
    DWORD biSizeImage ;      /* 说明图象的大小，以字节为单位。当用BI_RGB格式时，可设置为0 */
    DWORD  biXPelsPerMeter ;     /* 说明水平分辨率，用象素/米表示 */
    DWORD  biYPelsPerMeter ;     /* 说明垂直分辨率，用象素/米表示 */
    DWORD biClrUsed ;        /* 说明位图实际使用的彩色表中的颜色索引数 */
    DWORD biClrImportant ;   /* 说明对图象显示有重要影响的颜色索引的数目，如果是0，表示都重要 */
}__attribute__((packed))BITMAPINFOHEADER1 ;

/* BMP头文件 */
typedef struct
{
    WORD  bfType ;          /* 文件标志.只对'BM',用来识别BMP位图类型 */
    DWORD  bfSize ;          /* 文件大小,占四个字节 */
    WORD  bfReserved1 ;     /* 保留 */
    WORD  bfReserved2 ;     /* 保留 */
    DWORD  bfOffBits ;       /* 从文件开始到位图数据(bitmap data)开始之间的的偏移量 */
}__attribute__((packed))BITMAPFILEHEADER1 ;

/* 彩色表  */
typedef struct
{
    BYTE rgbBlue ;           /* 指定蓝色强度 */
    BYTE rgbGreen ;          /* 指定绿色强度 */
    BYTE rgbRed ;            /* 指定红色强度 */
    BYTE rgbReserved ;       /* 保留，设置为0 */
}__attribute__((packed))RGBQUAD1 ;

/* 位图信息头 */
typedef struct
{ 
    BITMAPFILEHEADER1 bmfHeader;
    BITMAPINFOHEADER1 bmiHeader;  
    uint32_t RGB_MASK[3];       /* 调色板用于存放RGB掩码 */
    //RGBQUAD bmiColors[256];
} __attribute__((packed))BITMAPINFO1; 


typedef RGBQUAD1 * LPRGBQUAD;    /* 彩色表 */



/* 图象数据压缩的类型 */
#define BI_RGB          0       /* 没有压缩.RGB 5,5,5 */
#define BI_RLE8         1       /* 每个象素8比特的RLE压缩编码，压缩格式由2字节组成(重复象素计数和颜色索引) */
#define BI_RLE4         2       /* 每个象素4比特的RLE压缩编码，压缩格式由2字节组成 */
#define BI_BITFIELDS    3       /* 每个象素的比特由指定的掩码决定 */



/* BMP编解码接口函数 */
uint8_t bmp_encode(uint8_t *filename,uint16_t *image_addr,uint16_t width,uint16_t height,uint8_t mode);

#endif








