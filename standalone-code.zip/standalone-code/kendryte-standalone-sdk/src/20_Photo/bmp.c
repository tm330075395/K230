/**
 ****************************************************************************************************
 * @file        bmp.c
 * @author      正点原子团队(ALIENTEK)
 * @version     V1.0
 * @date        2024-01-01
 * @brief       图片解码-bmp解码 代码
 * @license     Copyright (c) 2020-2032, 广州市星翼电子科技有限公司
 ****************************************************************************************************
 * @attention
 *
 * 实验平台:正点原子 K210开发板
 * 在线视频:www.yuanzige.com
 * 技术论坛:www.openedv.com
 * 公司网址:www.alientek.com
 * 购买地址:openedv.taobao.com
 *
 ****************************************************************************************************
 */

#include "string.h"
#include <stdio.h>
#include "bmp.h"
#include "iomem.h"


_pic_info picinfo;      /* 图片信息 */

/* 不使用内存分配 */
#if BMP_USE_MALLOC == 0
FIL f_bfile;
uint8_t bmpreadbuf[BMP_DBUF_SIZE];
#endif

/**
 * @brief       BMP编码函数
 *   @note      将当前LCD屏幕的指定区域截图,存为16位格式的BMP文件 RGB565格式.
 *              保存为rgb565则需要掩码,需要利用原来的调色板位置增加掩码.这里我们已经增加了掩码.
 *              保存为rgb555格式则需要颜色转换,耗时间比较久,所以保存为565是最快速的办法.
 *
 * @param       filename    : 包含存储路径的文件名(.bmp)
 * @param       x, y        : 起始坐标
 * @param       width,height: 区域大小
 * @param       acolor      : 附加的alphablend的颜色(这个仅对32位色bmp有效!!!)
 * @param       mode        : 保存模式
 *   @arg                     0, 仅仅创建新文件的方式编码;
 *   @arg                     1, 如果之前存在文件,则覆盖之前的文件.如果没有,则创建新的文件; 
 * @retval      操作结果
 *   @arg       0   , 成功
 *   @arg       其他, 错误码
 */
uint8_t bmp_encode(uint8_t *filename, uint16_t *image_addr, uint16_t width, uint16_t height, uint8_t mode)
{
    FIL *f_bmp;
    uint32_t bw = 0;
    uint16_t bmpheadsize;   /* bmp头大小 */
    BITMAPINFO1 hbmp;        /* bmp头 */
    uint8_t res = 0;
    uint16_t tx, ty;        /* 图像尺寸 */
    uint32_t *databuf;      /* 数据缓存区地址 */
    uint16_t pixcnt;        /* 像素计数器 */
    uint16_t bi4width;      /* 水平像素字节数 */
    uint32_t *addr = (uint32_t *)image_addr + 320 / 2 * 239; /* 偏移到最后一行开头 */

    if (width == 0 || height == 0)return PIC_WINDOW_ERR;        /* 区域错误 */

#if BMP_USE_MALLOC == 1     /* 使用malloc */
    
    /* 开辟至少bi4width大小的字节的内存区域 ,对320宽的屏,640个字节就够了 */
    databuf = (uint32_t *)iomem_malloc(320);

    if (databuf == NULL)return PIC_MEM_ERR;     /* 内存申请失败. */

    f_bmp = (FIL *)iomem_malloc(sizeof(FIL));   /* 开辟FIL字节的内存区域 */

    if (f_bmp == NULL)      /* 内存申请失败 */
    {
        iomem_free(databuf);
        return PIC_MEM_ERR;
    }
#else
    databuf = (uint16_t *)bmpreadbuf;
    f_bmp = &f_bfile;
#endif

    bmpheadsize = sizeof(hbmp);         /* 得到bmp文件头的大小 */
    memset((uint8_t *)&hbmp, 0, sizeof(hbmp));        /* 置零空申请到的内存 */

    hbmp.bmiHeader.biSize = sizeof(BITMAPINFOHEADER1);   /* 信息头大小 */
    hbmp.bmiHeader.biWidth = width;     /* bmp的宽度 */
    hbmp.bmiHeader.biHeight = height;   /* bmp的高度 */
    hbmp.bmiHeader.biPlanes = 1;        /* 恒为1 */
    hbmp.bmiHeader.biBitCount = 16;     /* bmp为16位色bmp */
    hbmp.bmiHeader.biCompression = BI_BITFIELDS;        /* 每个象素的比特由指定的掩码决定 */
    hbmp.bmiHeader.biSizeImage = hbmp.bmiHeader.biHeight * hbmp.bmiHeader.biWidth * hbmp.bmiHeader.biBitCount / 8;  /* bmp数据区大小 */

    hbmp.bmfHeader.bfType = ((uint16_t)'M' << 8) + 'B'; /* BM格式标志 */
    hbmp.bmfHeader.bfSize = bmpheadsize + hbmp.bmiHeader.biSizeImage; /* 整个bmp的大小 */
    hbmp.bmfHeader.bfOffBits = bmpheadsize; /* 到数据区的偏移 */

    hbmp.RGB_MASK[0] = 0X00F800;        /* 红色掩码 */
    hbmp.RGB_MASK[1] = 0X0007E0;        /* 绿色掩码 */
    hbmp.RGB_MASK[2] = 0X00001F;        /* 蓝色掩码 */

    if (mode == 1)
    {
        res = f_open(f_bmp, (const TCHAR *)filename, FA_READ | FA_WRITE);       /* 尝试打开之前的文件 */
    }
    
    if (mode == 0 || res == 0x04)
    {
        res = f_open(f_bmp, (const TCHAR *)filename, FA_WRITE | FA_CREATE_NEW); /* 模式0,或者尝试打开失败,则创建新文件 */
    }
    
    if ((hbmp.bmiHeader.biWidth * 2) % 4)   /* 水平像素(字节)不为4的倍数 */
    {
        bi4width = ((hbmp.bmiHeader.biWidth * 2) / 4 + 1) * 4;  /* 实际要写入的宽度像素,必须为4的倍数 */
    }
    else
    {
        bi4width = hbmp.bmiHeader.biWidth * 2;  /* 刚好为4的倍数 */
    }

    if (res == FR_OK)   /* 创建成功 */
    {
        res = f_write(f_bmp, (uint8_t *)&hbmp, bmpheadsize, &bw);   /* 写入BMP首部 */

        for (ty = height - 1; hbmp.bmiHeader.biHeight; ty--)
        {
            pixcnt = 0;

            for (tx = 0; tx <= width / 2;tx++)
            {     
                 /* 硬件原因在摄像头采集时已对相邻的数据调转，此处针对本硬件设计 */
                databuf[pixcnt] = ((addr[tx] & 0x0000FFFF) << 16) | ((addr[tx] & 0xFFFF0000) >> 16);   /* 读取RGB565数据*/       
                pixcnt++;                
            }

            addr = addr - width / 2;
            hbmp.bmiHeader.biHeight--;
            res = f_write(f_bmp, (uint8_t *)databuf, bi4width, &bw);    /* 写入数据 */
        }
        f_close(f_bmp);
    }

#if BMP_USE_MALLOC == 1     /* 使用malloc */
    iomem_free(databuf);
    iomem_free(f_bmp);
#endif
    return res;
}

















