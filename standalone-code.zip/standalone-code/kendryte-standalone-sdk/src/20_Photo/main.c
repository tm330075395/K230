/**
 ****************************************************************************************************
 * @file        main.c
 * @author      正点原子团队(ALIENTEK)
 * @version     V1.0
 * @date        2024-01-01
 * @brief       照相机 实验
 * @license     Copyright (c) 2020-2032, 广州市星翼电子科技有限公司
 ****************************************************************************************************
 * @attention
 *
 * 实验平台:正点原子 K210开发板
 * 在线视频:www.yuanzige.com
 * 技术论坛:www.openedv.com
 * 公司网址:www.alientek.com
 * 购买地址:openedv.taobao.com
 * 
 ****************************************************************************************************
 */
#include <stddef.h>
#include <stdio.h>
#include "iomem.h"
#include "sysctl.h"
#include "sleep.h"
#include "bmp.h"
#include "./BSP/CAMERA/camera.h"
#include "./BSP/KEY/key.h"
#include "./BSP/SDCARD/sdcard.h"
#include "./BSP/FATFS/ff.h"
#include "./BSP/LCD/lcd.h"


/**
 * @brief       文件名自增（避免覆盖）
 *   @note      bmp组合成: 形如 "0:PHOTO/PIC13141.bmp" 的文件名
 *              jpg组合成: 形如 "0:PHOTO/PIC13141.jpg" 的文件名
 * @param       pname : 有效的文件名
 * @param       mode  : 0, 创建.bmp文件;  1, 创建.jpg文件;
 * @retval      无
 */
void camera_new_pathname(uint8_t *pname, uint8_t mode)
{
    uint8_t res;
    uint16_t index = 0;
    FIL *ftemp;
    
    ftemp = (FIL *)iomem_malloc(sizeof(FIL));   /* 开辟FIL字节的内存区域 */

    if (ftemp == NULL) return;  /* 内存申请失败 */

    while (index < 0XFFFF)
    {
        sprintf((char *)pname, "0:PHOTO/PIC%05d.bmp", index);      
        res = f_open(ftemp, (const TCHAR *)pname, FA_READ); /* 尝试打开这个文件 */

        if (res == FR_NO_FILE) break;   /* 该文件名不存在, 正是我们需要的 */

        index++;
    }
    iomem_free(ftemp);
}

int main(void)
{
    uint8_t key;
    uint8_t *disp;
    FRESULT res;
    FATFS fs;
    uint8_t *pname;         /* 带路径的文件名 */

    sysctl_pll_set_freq(SYSCTL_PLL0, 800000000);
    sysctl_pll_set_freq(SYSCTL_PLL1, 400000000);
    sysctl_pll_set_freq(SYSCTL_PLL2, 45158400);
    sysctl_set_power_mode(SYSCTL_POWER_BANK6, SYSCTL_POWER_V18);
    sysctl_set_power_mode(SYSCTL_POWER_BANK7, SYSCTL_POWER_V18);
    sysctl_set_spi0_dvp_data(1);

    lcd_init();
    lcd_set_direction(DIR_YX_LRUD);
    key_init();
    camera_init(0);
    camera_set_pixformat(PIXFORMAT_RGB565);
    camera_set_framesize(320, 240);
    /* 根据摄像头选择是否翻转 */
    camera_set_hmirror(1);
    camera_set_vflip(1);

    pname = iomem_malloc(30);                               /* 为带路径的文件名分配30个字节的内存 */
    /* 初始化SD卡 */
    if (sd_init() != 0)
    {
        printf("SD card initialization failed!\n");
        while (1);
    }
    printf("SD card initialization succeed!\n");

    /* 文件系统挂载SD卡 */
    res = f_mount(&fs, _T("0:"), 1);
    if (res != FR_OK)
    {
        printf("SD card mount failed! Error code: %d\n", res);
        while (1);
    }
    printf("SD card mount succeed!\n");

    lcd_draw_string(10, 30, "KEY0:Take BMP ", RED); 
    sleep(3);
    while (1)
    {
        key = key_scan(0);                  /* 得到键值 */
        if (camera_snapshot(&disp, NULL) == 0)
        {
            lcd_draw_picture(0, 0, 320, 240, (uint16_t *)disp);
            camera_snapshot_release();
        } 
        if (key == KEY0_PRES)
        {
            camera_new_pathname(pname, 0);  /* 得到文件名 */   
            res = bmp_encode(pname,(uint16_t *)disp ,320, 240, 1);
        }
    }
}
