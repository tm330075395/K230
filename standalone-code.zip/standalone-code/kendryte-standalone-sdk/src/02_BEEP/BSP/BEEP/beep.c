/**
 ****************************************************************************************************
 * @file        beep.c
 * @author      正点原子团队(ALIENTEK)
 * @version     V1.0
 * @date        2024-01-01
 * @brief       蜂鸣器 驱动代码
 * @license     Copyright (c) 2020-2032, 广州市星翼电子科技有限公司
 ****************************************************************************************************
 * @attention
 * 
 * 实验平台:正点原子 K210开发板
 * 在线视频:www.yuanzige.com
 * 技术论坛:www.openedv.com
 * 公司网址:www.alientek.com
 * 购买地址:openedv.taobao.com
 *
 ****************************************************************************************************
 */

#include "beep.h"
#include "fpioa.h"

/**
 * @brief   初始化蜂鸣器
 * @param   无
 * @retval  无
 */
void beep_init(void)
{
    gpio_init();     /* 使能GPIO时钟 */
    
    fpioa_set_function(PIN_LED_BEEP, FUNC_BEEP);
    
    /* 设置蜂鸣器的GPIO模式为输出 */
    gpio_set_drive_mode(BEEP_GPIONUM, GPIO_DM_OUTPUT);
    
    /* 先关闭蜂鸣器 */
    gpio_set_pin(BEEP_GPIONUM, GPIO_PV_LOW);
}
