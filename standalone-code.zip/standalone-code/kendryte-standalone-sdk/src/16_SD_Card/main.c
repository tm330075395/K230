/**
 ****************************************************************************************************
 * @file        main.c
 * @author      正点原子团队(ALIENTEK)
 * @version     V1.0
 * @date        2024-01-01
 * @brief       SD卡 实验
 * @license     Copyright (c) 2020-2032, 广州市星翼电子科技有限公司
 ****************************************************************************************************
 * @attention
 *
 * 实验平台:正点原子 K210开发板
 * 在线视频:www.yuanzige.com
 * 技术论坛:www.openedv.com
 * 公司网址:www.alientek.com
 * 购买地址:openedv.taobao.com
 * 
 ****************************************************************************************************
 */

#include <stddef.h>
#include <stdio.h>
#include "iomem.h"
#include "sleep.h"
#include "sysctl.h"
#include "./BSP/SDCARD/sdcard.h"
#include "./BSP/KEY/key.h"
#include "./BSP/LCD/lcd.h"


/**
 * @brief       测试SD卡的读取
 *   @note      从secaddr地址开始,读取seccnt个扇区的数据
 * @param       secaddr : 扇区地址
 * @param       seccnt  : 扇区数
 * @retval      无
 */
void sd_test_read(uint32_t secaddr, uint32_t seccnt)
{
    uint32_t i;
    uint8_t *rbuff = NULL;
    uint8_t sta = 0;

    rbuff = (uint8_t *)iomem_malloc(seccnt * cardinfo.CardBlockSize);

    sta = sd_read_sector_dma(rbuff, secaddr, seccnt); /* 读取secaddr扇区开始的内容 */

    if (sta == 0)
    {
        lcd_draw_fill_rectangle(10, 50, 319, 70, WHITE);         /* 清除显示 */
        lcd_draw_string(10, 50, "USB Sending Data...", BLUE);
        printf("SECTOR %d DATA:\r\n", secaddr);

        for (i = 0; i < seccnt * 512; i++)
        {
            printf("%x ", rbuff[i]);              /* 打印secaddr开始的扇区数据 */
        }

        printf("\r\nDATA ENDED\r\n");
        lcd_draw_fill_rectangle(10, 50, 319, 70, WHITE);         /* 清除显示 */
        lcd_draw_string(10, 50, "USB Send Data Over!", BLUE);
    }
    else
    {
        printf("err:%d\r\n", sta);
        lcd_draw_fill_rectangle(10, 50, 319, 70, WHITE);         /* 清除显示 */
        lcd_draw_string(10, 50, "SD read Failure!      ", BLUE);
    }

    iomem_free(rbuff);; /* 释放内存 */
}

/**
 * @brief       测试SD卡的写入
 *   @note      从secaddr地址开始,写入seccnt个扇区的数据
 *              慎用!! 最好写全是0XFF的扇区,否则可能损坏SD卡.
 *
 * @param       secaddr : 扇区地址
 * @param       seccnt  : 扇区数
 * @retval      无
 */
void sd_test_write(uint32_t secaddr, uint32_t seccnt)
{
    uint32_t i;
    uint8_t *wbuff = NULL;
    uint8_t sta = 0;

    wbuff = (uint8_t *)iomem_malloc(seccnt * cardinfo.CardBlockSize);

    for (i = 0; i < seccnt * 512; i++)                 /* 初始化写入的数据,是3的倍数. */
    {
        wbuff[i] = i * 3;
    }

    sta = sd_write_sector_dma(wbuff, secaddr, seccnt); /* 从secaddr扇区开始写入seccnt个扇区内容 */

    if (sta == 0)
    {
        printf("Write over!\r\n");
    }
    else
    {
        printf("err:%d\r\n", sta);
    }

    iomem_free(wbuff); /* 释放内存 */
}

int main(void)
{
    uint8_t key;

    char data1show[35];
    char data2show[30];

    sysctl_pll_set_freq(SYSCTL_PLL0, 800000000);
    sysctl_pll_set_freq(SYSCTL_PLL1, 400000000);
    sysctl_pll_set_freq(SYSCTL_PLL2, 45158400);
    sysctl_set_power_mode(SYSCTL_POWER_BANK6, SYSCTL_POWER_V18);
    sysctl_set_power_mode(SYSCTL_POWER_BANK7, SYSCTL_POWER_V18);
    sysctl_set_spi0_dvp_data(1);

    key_init();                             /* 初始化按键 */
    lcd_init();                             /* 初始化LCD */
    lcd_set_direction(DIR_YX_LRUD);

    /* 初始化SD卡 */
    if (sd_init() != 0)
    {
        printf("SD card initialization failed!\n");
        while (1);
    }

    /* 显示SD卡容量大小 */
    printf("SD card capacity: %ldMB\n", cardinfo.CardCapacity >> 20);
    printf("SD card sector size: %dB\n", cardinfo.CardBlockSize);

    sprintf((char *)data1show, "SD card capacity: %ldMB", cardinfo.CardCapacity >> 20);
    sprintf((char *)data2show, "SD card sector size: %dB", cardinfo.CardBlockSize);
    lcd_draw_string(10, 10, (char *)data1show, BLUE);         /* 显示SD卡容量 */
    lcd_draw_string(10, 30, (char *)data2show, BLUE);         /* 显示扇区大小 */

    while (1)
    {
        key = key_scan(0);
        if (key == KEY0_PRES)       /* KEY0按下了 */
        {
            sd_test_read(0,1);      /* 从0扇区读取1*512字节的内容 */
        }
        else if (key == KEY1_PRES)  /* KEY1按下,写入 */
        {
            sd_test_write(0,1);     /* 从0扇区写入1*512字节的内容 */
            lcd_draw_fill_rectangle(10, 50, 319, 70, WHITE);     /* 清除显示 */
            lcd_draw_string(10, 50, "SD Write Finished!", BLUE); /* 提示传送完成 */
        }
        msleep(10); 
    }
}
