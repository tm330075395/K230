/**
 ****************************************************************************************************
 * @file        timer.c
 * @author      正点原子团队(ALIENTEK)
 * @version     V1.0
 * @date        2024-01-01
 * @brief       定时器 驱动代码
 * @license     Copyright (c) 2020-2032, 广州市星翼电子科技有限公司
 ****************************************************************************************************
 * @attention
 * 
 * 实验平台:正点原子 K210开发板
 * 在线视频:www.yuanzige.com
 * 技术论坛:www.openedv.com
 * 公司网址:www.alientek.com
 * 购买地址:openedv.taobao.com
 *
 ****************************************************************************************************
 */

#include "timer.h"
#include "sysctl.h"
#include "sleep.h"
#include "plic.h"
#include "../../../../lib/drivers/include/timer.h"
#include "../LED/led.h"

uint32_t g_count;

/**
 * @brief   定时器中断回调
 * @param   ctx: 回调参数
 * @retval  无
 */
int timer_timeout_cb(void *ctx) 
{
    LEDR(0);      /* 红灯亮 */
    msleep(500);  /* 延时500毫秒 */
    LEDR(1);      /* 红灯灭 */
    return 0;
}

/**
 * @brief   初始化定时器
 * @param   无
 * @retval  无
 */
void gtimer_init(void)
{
    /* 系统中断初始化 */
    plic_init();
    sysctl_enable_irq();

    /* 定时器初始化 */
    timer_init(TIMER_DEVICE_0);
    /* 设置定时器超时时间，单位为ns，即500毫秒 */
    timer_set_interval(TIMER_DEVICE_0, TIMER_CHANNEL_0, 500 * 1e6);
    /* 设置定时器中断回调 */
    timer_irq_register(TIMER_DEVICE_0, TIMER_CHANNEL_0, 0, 1, timer_timeout_cb, &g_count);
    /* 使能定时器 */
    timer_set_enable(TIMER_DEVICE_0, TIMER_CHANNEL_0, 1);
}
