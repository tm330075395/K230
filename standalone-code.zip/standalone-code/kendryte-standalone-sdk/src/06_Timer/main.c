/**
 ****************************************************************************************************
 * @file        main.c
 * @author      正点原子团队(ALIENTEK)
 * @version     V1.0
 * @date        2024-01-01
 * @brief       定时器 实验
 * @license     Copyright (c) 2020-2032, 广州市星翼电子科技有限公司
 ****************************************************************************************************
 * @attention
 *
 * 实验平台:正点原子 K210开发板
 * 在线视频:www.yuanzige.com
 * 技术论坛:www.openedv.com
 * 公司网址:www.alientek.com
 * 购买地址:openedv.taobao.com
 ****************************************************************************************************
 */
#include "sleep.h"
#include "plic.h"
#include "timer.h"
#include "./BSP/KEY/key.h"
#include "./BSP/LED/led.h"
#include "./BSP/TIMER/timer.h"

int main(void)
{
    uint8_t key;
    led_init();    /* LED初始化 */
    key_init();    /* 按键初始化 */
    gtimer_init(); /* 定时器初始化 */
    
    while (1)
    {
        key = key_scan(0);                  /* 得到键值 */
        if (key == KEY0_PRES)
        {
            timer_set_enable(TIMER_DEVICE_0, TIMER_CHANNEL_0, 1); /* 开启定时器0 */
        }
        else if(key == KEY1_PRES)
        {
            timer_set_enable(TIMER_DEVICE_0, TIMER_CHANNEL_0, 0); /* 关闭定时器0 */
        }
        else msleep(10);
    }
}
