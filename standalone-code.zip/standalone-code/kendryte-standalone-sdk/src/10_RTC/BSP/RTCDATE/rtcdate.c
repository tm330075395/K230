/**
 ****************************************************************************************************
 * @file        rtcdate.c
 * @author      正点原子团队(ALIENTEK)
 * @version     V1.0
 * @date        2024-01-01
 * @brief       RTC获取系统时间 驱动代码
 * @license     Copyright (c) 2020-2032, 广州市星翼电子科技有限公司
 ****************************************************************************************************
 * @attention
 * 
 * 实验平台:正点原子 K210开发板
 * 在线视频:www.yuanzige.com
 * 技术论坛:www.openedv.com
 * 公司网址:www.alientek.com
 * 购买地址:openedv.taobao.com
 *
 ****************************************************************************************************
 */

#include "rtcdate.h"
#include <stdlib.h>
#include "sysctl.h"
#include "plic.h"

/**
 * @brief   查找字符串中第n个分隔符后的地址
 * @param   string   :需要查找的字符串
 * @param   interval :分隔符
 * @param   index    :第n个分割符
 * @retval  返回第n个分隔符后的地址
 */
static const char *find_field(const char *string, const char interval, uint8_t index)
{
    uint8_t index_loop = 0;
    const char *field = string;

    while (index_loop < index)
    {
        while (field[0] != interval)
        {
            field++;
        }
        while (field[0] == interval)
        {
            field++;       /* 偏移到分隔符地址后 */
        }
        index_loop++;
    }

    return field;
}

/**
 * @brief   获取系统时间
 * @param   compile_time :RTC的日期、时间结构体指针
 * @retval  无
 */
void get_compile_time(rtc_date_time_t *compile_time)
{
    const char date[12] = {__DATE__};
    const char time[9] = {__TIME__};
    uint8_t length;
    const char *ptr;
    char buffer[100];
    uint8_t month_index;
    const char *month_list[12] = {"Jan", "Feb", "Mar", "Apr", "May", "Jun", "Jul", "Aug", "Sep", "Oct", "Nov", "Dec"};

    if (compile_time == NULL)
    {
        return;
    }

    /* Set to default */
    compile_time->sec = 0;
    compile_time->min = 0;
    compile_time->hour = 0;
    compile_time->week = 6;
    compile_time->day = 1;
    compile_time->month = 1;
    compile_time->year = 2000;

    /* Month */
    ptr = find_field(date, ' ', 0);
    length = (uint8_t)(strchr(ptr, ' ') - ptr);
    strncpy(buffer, ptr, length);
    buffer[length] = '\0';
    for (month_index=0; month_index<sizeof(month_list)/sizeof(month_list[0]); month_index++)
    {
        if (strcmp(buffer, month_list[month_index]) == 0)
        {
            compile_time->month = month_index + 1;
        }
    }
    
    /* Day */
    ptr = find_field(date, ' ', 1);
    length = (uint8_t)(strchr(ptr, ' ') - ptr);
    strncpy(buffer, ptr, length);
    buffer[length] = '\0';
    compile_time->day = atoi(buffer);

    /* Year */
    ptr = find_field(date, ' ', 2);
    length = (uint8_t)(strchr(ptr, ' ') - ptr);
    strncpy(buffer, ptr, length);
    buffer[length] = '\0';
    compile_time->year = atoi(buffer);

    /* Hour */
    ptr = find_field(time, ':', 0);
    length = (uint8_t)(strchr(ptr, ':') - ptr);
    strncpy(buffer, ptr, length);
    buffer[length] = '\0';
    compile_time->hour = atoi(buffer);

    /* Minute */
    ptr = find_field(time, ':', 1);
    length = (uint8_t)(strchr(ptr, ':') - ptr);
    strncpy(buffer, ptr, length);
    buffer[length] = '\0';
    compile_time->min = atoi(buffer);

    /* Second */
    ptr = find_field(time, ':', 2);
    length = (uint8_t)(strchr(ptr, '\0') - ptr);
    strncpy(buffer, ptr, length);
    buffer[length] = '\0';
    compile_time->sec = atoi(buffer);

    /* Week */
    compile_time->week = rtc_get_wday(compile_time->year, compile_time->month, compile_time->day);
}