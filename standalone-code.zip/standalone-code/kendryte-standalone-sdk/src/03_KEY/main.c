/**
 ****************************************************************************************************
 * @file        main.c
 * @author      正点原子团队(ALIENTEK)
 * @version     V1.0
 * @date        2024-01-01
 * @brief       按键输入 实验
 * @license     Copyright (c) 2020-2032, 广州市星翼电子科技有限公司
 ****************************************************************************************************
 * @attention
 *
 * 实验平台:正点原子 K210开发板
 * 在线视频:www.yuanzige.com
 * 技术论坛:www.openedv.com
 * 公司网址:www.alientek.com
 * 购买地址:openedv.taobao.com
 ****************************************************************************************************
 */

#include <stdio.h>
#include <unistd.h>
#include <sleep.h>
#include "./BSP/KEY/key.h"
#include "./BSP/LED/led.h"

int main(void)
{
    uint8_t key;

    led_init();    /* LED初始化 */
    key_init();    /* 按键初始化 */

    while (1)
    {
        key = key_scan(0);                  /* 得到键值 */

        if (key)
        {
            switch (key)
            {
                case KEY2_PRES:             /* 控制红灯亮 */
                    LEDR(0);
                    LEDB(1);
                    break;

                case KEY1_PRES:             /* 控制蓝灯亮 */
                    LEDR(1);
                    LEDB(0);
                    break;

                case KEY0_PRES:             /* 同时关闭红灯和蓝灯 */
                    LEDR(1);
                    LEDB(1);
                    break;
            }
        }
        else
        {
            msleep(10);
        }
    }
}
