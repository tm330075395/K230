/**
 ****************************************************************************************************
 * @file        norflash.h
 * @author      正点原子团队(ALIENTEK)
 * @version     V1.0
 * @date        2024-01-01
 * @brief       NOR FLASH(25QXX)驱动代码
 * @license     Copyright (c) 2020-2032, 广州市星翼电子科技有限公司
 ****************************************************************************************************
 * @attention
 * 
 * 实验平台:正点原子 K210开发板
 * 在线视频:www.yuanzige.com
 * 技术论坛:www.openedv.com
 * 公司网址:www.alientek.com
 * 购买地址:openedv.taobao.com
 *
 ****************************************************************************************************
 */

#ifndef __NORFLASH_H
#define __NORFLASH_H

#include <stdio.h>

/* 函数声明 */
void norflash_init(void);                   /* 初始化norflash */
uint16_t norflash_read_id(uint8_t *manuf_id, uint8_t *device_id);    /* 读取FLASH ID */
void norflash_erase_chip(void);             /* 整片擦除 */
void norflash_erase_sector(uint32_t saddr); /* 扇区擦除 */
void norflash_read(uint8_t *pbuf, uint32_t addr, uint32_t datalen);     /* 读取flash */
void norflash_write(uint8_t *pbuf, uint32_t addr, uint32_t datalen);    /* 写入flash */

#endif
