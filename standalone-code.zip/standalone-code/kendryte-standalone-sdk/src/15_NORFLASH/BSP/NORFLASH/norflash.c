/**
 ****************************************************************************************************
 * @file        norflash.c
 * @author      正点原子团队(ALIENTEK)
 * @version     V1.0
 * @date        2024-01-01
 * @brief       NOR FLASH(25QXX)驱动代码
 * @license     Copyright (c) 2020-2032, 广州市星翼电子科技有限公司
 ****************************************************************************************************
 * @attention
 * 
 * 实验平台:正点原子 K210开发板
 * 在线视频:www.yuanzige.com
 * 技术论坛:www.openedv.com
 * 公司网址:www.alientek.com
 * 购买地址:openedv.taobao.com
 *
 ****************************************************************************************************
 */

#include "norflash.h"
#include "fpioa.h"
#include "w25qxx.h"

/**
 * @brief       初始化NOR FLASH
 * @param       无
 * @retval      0:成功  1：失败
 */
void norflash_init(void)
{
    uint8_t manuf_id, device_id;
    uint8_t spi_index = 3, spi_ss = 0;
    w25qxx_init(spi_index, spi_ss);
    w25qxx_enable_quad_mode();   /* flash 四倍模式开启*/
    /* 读取flash的ID */
    norflash_read_id(&manuf_id, &device_id);
    printf("manuf_id:0x%02x, device_id:0x%02x\r\n", manuf_id, device_id);

    if ((manuf_id != 0xEF && manuf_id != 0xC8) || (device_id != 0x17 && device_id != 0x16))
    {
        /* flash初始化失败 */
        printf("w25qxx_read_id error\n");
        printf("manuf_id:0x%02x, device_id:0x%02x\r\n", manuf_id, device_id);
        return 0;
    }
    else
    {
        return 1;
    } 
}

/**
 * @brief       读取芯片ID
 *   @note      0XEF17表示W25Q128
 * @param       manuf_id  ：厂家ID
 * @param       device_id ：芯片ID
 * @retval      无
 */
uint16_t norflash_read_id(uint8_t *manuf_id, uint8_t *device_id)
{
    w25qxx_read_id(manuf_id, device_id);
}

/**
 * @brief       读取SPI FLASH
 *   @note      在指定地址开始读取指定长度的数据
 * @param       pbuf    : 数据存储区
 * @param       addr    : 开始读取的地址
 * @param       datalen : 要读取的字节数
 * @retval      无
 */
void norflash_read(uint8_t *pbuf, uint32_t addr, uint32_t datalen)
{
    /* norflash读取数据 */
    w25qxx_read_data(addr, pbuf, datalen, W25QXX_QUAD_FAST);
}

/**
 * @brief       写SPI FLASH
 *   @note      在指定地址开始写入指定长度的数据 , 该函数带擦除操作!
 *              SPI FLASH 一般是: 256个字节为一个Page, 4Kbytes为一个Sector, 16个扇区为1个Block
 *              擦除的最小单位为Sector.
 *
 * @param       pbuf    : 数据存储区
 * @param       addr    : 开始写入的地址
 * @param       datalen : 要写入的字节数
 * @retval      无
 */
void norflash_write(uint8_t *pbuf, uint32_t addr, uint32_t datalen)
{
    w25qxx_write_data(addr, pbuf, datalen);
}

/**
 * @brief       擦除整个芯片
 *   @note      等待时间超长...
 * @param       无
 * @retval      无
 */
void norflash_erase_chip(void)
{
    w25qxx_chip_erase();
}

/**
 * @brief       擦除一个扇区
 *   @note      注意,这里是扇区地址,不是字节地址!!
 * 
 * @param       saddr : 扇区地址 根据实际容量设置
 * @retval      无
 */
void norflash_erase_sector(uint32_t saddr)
{
    //printf("fe:%x\r\n", saddr);   /* 监视falsh擦除情况,测试用 */
    w25qxx_sector_erase(saddr);
}
