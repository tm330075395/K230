/**
 ****************************************************************************************************
 * @file        main.c
 * @author      正点原子团队(ALIENTEK)
 * @version     V1.0
 * @date        2024-01-01
 * @brief       NORFLASH 实验
 * @license     Copyright (c) 2020-2032, 广州市星翼电子科技有限公司
 ****************************************************************************************************
 * @attention
 *
 * 实验平台:正点原子 K210开发板
 * 在线视频:www.yuanzige.com
 * 技术论坛:www.openedv.com
 * 公司网址:www.alientek.com
 * 购买地址:openedv.taobao.com
 * 
 ****************************************************************************************************
 */

#include <stdio.h>
#include "sysctl.h"
#include "sleep.h"
#include "./BSP/NORFLASH/norflash.h"
#include "./BSP/KEY/key.h"
#include "./BSP/LCD/lcd.h"

/* 要写入到FLASH的字符串数组 */
const uint8_t g_text_buf[] = {"NORFLASH TEST"};

#define TEXT_SIZE   sizeof(g_text_buf) + 4      /* TEXT字符串长度 */
#define DATA_ADDRESS 0xB00000                   /* 读写地址 */

int main(void)
{
    uint8_t key;
    uint8_t i = 0;
    uint8_t datatemp[TEXT_SIZE];

    sysctl_pll_set_freq(SYSCTL_PLL0, 800000000);
    sysctl_pll_set_freq(SYSCTL_PLL1, 400000000);
    sysctl_pll_set_freq(SYSCTL_PLL2, 45158400);
    sysctl_set_power_mode(SYSCTL_POWER_BANK6, SYSCTL_POWER_V18);
    sysctl_set_power_mode(SYSCTL_POWER_BANK7, SYSCTL_POWER_V18);
    sysctl_set_spi0_dvp_data(1);

    lcd_init();                             /* 初始化LCD */
    lcd_set_direction(DIR_YX_LRUD);
    key_init();                             /* 初始化按键 */
    norflash_init();                        /* 初始化NORFLASH */

    lcd_draw_string(10, 10, "KEY1:Write  KEY0:Read", RED); /* 显示提示信息 */
    lcd_draw_string(10, 30, "SPI FLASH Ready!", BLUE);

    while (1)
    {
        key = key_scan(0);

        if (key == KEY1_PRES)   /* KEY1按下,写入 */
        {
            lcd_draw_fill_rectangle(0, 50, 319, 90, WHITE);         /* 清除显示 */
            lcd_draw_string(10, 50, "Start Write FLASH.", BLUE);

            sprintf((char *)datatemp, "%s%d", (char *)g_text_buf, i);
            norflash_write((uint8_t *)datatemp, DATA_ADDRESS, TEXT_SIZE);      /* 从DATA_ADDRESS地址处开始,写入SIZE长度的数据 */
            lcd_draw_fill_rectangle(10, 50, 319, 70, WHITE);        /* 清除显示 */
            lcd_draw_string(10, 50, "FLASH Write Finished!", BLUE); /* 提示传送完成 */
        }

        else if (key == KEY0_PRES)   /* KEY0按下,读取字符串并显示 */
        {
            lcd_draw_fill_rectangle(10, 50, 319, 90, WHITE);         /* 清除显示 */
            lcd_draw_string(10, 50, "Start Read FLASH.", BLUE); 
            norflash_read(datatemp, DATA_ADDRESS, TEXT_SIZE);        /* 从DATA_ADDRESS地址处开始,读出SIZE个字节 */
            lcd_draw_fill_rectangle(10, 50, 319, 70, WHITE);         /* 清除显示 */
            lcd_draw_string(10, 50, "The Data Readed Is:   ", BLUE); /* 提示传送完成 */
            lcd_draw_string(10, 70, (char *)datatemp, BLUE);         /* 显示读到的字符串 */
        }

        i++;
        if (i > 200)
        {
            i = 0;
        }
        
        msleep(10);
    }
}
