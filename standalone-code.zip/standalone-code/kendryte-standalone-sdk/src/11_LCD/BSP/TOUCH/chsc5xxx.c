/**
 ****************************************************************************************************
 * @file        CHSC5XXX.c
 * @author      正点原子团队(正点原子)
 * @version     V1.1
 * @date        2024-06-25
 * @brief       2.4寸电容触摸屏-CHSC5xxx 驱动代码
 *
 * @license     Copyright (c) 2020-2032, 广州市星翼电子科技有限公司
 ****************************************************************************************************
 * @attention
 *
 * 实验平台:正点原子 ESP32-S3 带外壳版本
 * 在线视频:www.yuanzige.com
 * 技术论坛:www.openedv.com
 * 公司网址:www.alientek.com
 * 购买地址:openedv.taobao.com
 *
 ****************************************************************************************************
 */

#include "chsc5xxx.h"
#include <sleep.h>

/* 默认支持的触摸屏点数(5点触摸) */
uint8_t g_chsc_tnum = 5;

/**
 * @brief       向chsc5xxx写入数据
 * @param       reg : 起始寄存器地址
 * @param       buf : 数据缓缓存区
 * @param       len : 写数据长度
 * @retval      esp_err_t ：0, 成功; 1, 失败;
 */
unsigned char chsc5xxx_wr_reg(uint32_t reg, uint8_t *buf, uint8_t len)
{
    uint16_t error = 1;
    error = tp_i2c_hd_write(CHSC5432_ADDR, reg, len, buf);
    return error;
}

/**
 * @brief       从chsc5xxx读出数据
 * @param       reg : 起始寄存器地址
 * @param       buf : 数据缓缓存区
 * @param       len : 读数据长度
 * @retval      esp_err_t ：0, 成功; 1, 失败;
 */
unsigned char chsc5xxx_rd_reg(uint32_t reg, uint8_t *buf, uint8_t len)
{
    uint16_t error = 1;
    error = tp_i2c_hd_read(CHSC5432_ADDR, reg, len, buf);
    return error;
}

extern int semi_touch_init();

/**
 * @brief       SH3001的IIC引脚初始化，绑定GPIO功能
 * @param       无
 * @retval      返回值 : 无
 */
static void sh3001_hardware_init(void)
{
    /* I2C SH3001 */
    fpioa_set_function(PIN_IMU_SCL, FUNC_ICM_SCL);
    fpioa_set_function(PIN_IMU_SDA, FUNC_ICM_SDA);
}

/**
 * @brief       初始化chsc5xxx触摸屏
 * @param       无
 * @retval      0, 初始化成功; 1, 初始化失败;
 */
uint8_t chsc5xxx_init(void)
{
    uint8_t temp[4];

    gpio_init();     /* 使能GPIO时钟 */
    
    fpioa_set_function(PIN_CT_RST, FUNC_CT_RST);
    
    /* 设置复位引脚的GPIO模式为输出 */
    gpio_set_drive_mode(CT_RST_GPIONUM, GPIO_DM_OUTPUT);

    sh3001_hardware_init();        /* 绑定IIC功能引脚 */
    tp_i2c_hardware_init(CHSC5432_ADDR); /* 初始化IIC */
    msleep(10);

    /* 复位触摸屏 */
    CT_RST(0);
    msleep(100);
    CT_RST(1);
    msleep(100);

    chsc5xxx_rd_reg(CHSCXXX_PID_REG, temp, 4);              /* 从0x20000080地址读取ID */
    temp[3] = 0;
    // ESP_LOGI(touch_name, "CTP:0x%x", temp[0]);

    return 0;
}

/**
 * @brief       扫描触摸屏(采用查询方式)
 * @param       mode : 电容屏未用到次参数, 为了兼容电阻屏
 * @retval      当前触屏状态
 *   @arg       0, 触屏无触摸; 
 *   @arg       1, 触屏有触摸;
 */
uint8_t chsc5xxx_scan(uint8_t mode)
{
    uint8_t buf[28];
    uint8_t i = 0;
    uint8_t res = 0;
    uint16_t temp;
    uint16_t tempsta;
    static uint8_t t = 0;                            /* 控制查询间隔,从而降低CPU占用率 */
    t++;

    if ((t % 5) == 0 || t < 5)                       /* 空闲时,每进入10次CTP_Scan函数才检测1次,从而节省CPU使用率 */
    {
        chsc5xxx_rd_reg(CHSCXXX_CTRL_REG, buf, 28); /* 官方建议一次读取28字节，然后在分析触摸坐标 */
        mode = 0x80 + buf[1];
        //printf("mode:%d\n",mode);

        /* 判断是否有触摸按下 */
        if ((mode & 0XF) && ((mode & 0XF) <= g_chsc_tnum))
        {
            temp = 0XFFFF << (mode & 0XF);
            tempsta = tp_dev.sta;
            tp_dev.sta = (~temp) | TP_PRES_DOWN | TP_CATH_PRES;
            tp_dev.x[g_chsc_tnum - 1] = tp_dev.x[0];
            tp_dev.y[g_chsc_tnum - 1] = tp_dev.y[0];
            /* 获取触摸坐标 */
            for (i = 0; i < g_chsc_tnum; i++)
            {
                if (tp_dev.sta & (1 << i))
                {
                    if (tp_dev.touchtype & 0X01)                        /* 横屏 */
                    {
                        tp_dev.x[i] = ((uint16_t)(buf[5 + i * 5] >> 4 ) << 8) + buf[3 + i * 5];
                        tp_dev.y[i] = 240 - (((uint16_t)(buf[5 + i * 5] & 0x0F) << 8) + buf[2 + i * 5]);
                    }
                    else                                                /* 竖屏 */
                    {
                        tp_dev.x[i] = ((uint16_t)(buf[5 + i * 5] & 0x0F) << 8) + buf[2 + i * 5];
                        tp_dev.y[i] = ((uint16_t)((buf[5 + i * 5] & 0xF0) >> 4 ) << 8) + buf[3 + i * 5];
                    }

                    //printf("x[%d]:%d,y[%d]:%d\r\n", i, tp_dev.x[i], i, tp_dev.y[i]);
                }
            }
            res = 1;
            /* 触摸坐标超出屏幕范围 */
            if (tp_dev.x[0] > 320 || tp_dev.y[0] > 240)
            {
                /* 触摸数量是否大于1~5 */
                if ((mode & 0XF) > 1)
                {
                    tp_dev.x[0] = tp_dev.x[1];
                    tp_dev.y[0] = tp_dev.y[1];
                    t = 0;
                }
                else    /* 超出范围且未检测到触摸点 */
                {
                    tp_dev.x[0] = tp_dev.x[g_chsc_tnum - 1];
                    tp_dev.y[0] = tp_dev.y[g_chsc_tnum - 1];
                    mode = 0X80;
                    tp_dev.sta = tempsta;
                }
            }
            else 
            {
                t = 0;
            }
        }
    }

    //printf("x[0]:%d,y[0]:%d\r\n", tp_dev.x[0], tp_dev.y[0]);
    
    /* 超出触摸范围 */
    if ((mode & 0X8F) == 0X80)
    {
        if (tp_dev.sta & TP_PRES_DOWN)
        {
            tp_dev.sta &= ~TP_PRES_DOWN;
        }
        else
        {
            tp_dev.x[0] = 0xffff;
            tp_dev.y[0] = 0xffff;
            tp_dev.sta &= 0XE000;
        }
    }

    if (t > 240)
    {
        t = 10;
    }

    return res;
}
