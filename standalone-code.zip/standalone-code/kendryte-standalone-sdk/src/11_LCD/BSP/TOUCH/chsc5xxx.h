/**
 ****************************************************************************************************
 * @file        CHSC5XXX.h
 * @author      正点原子团队(正点原子)
 * @version     V1.1
 * @date        2024-06-25
 * @brief       2.4寸电容触摸屏-CHSC5xxx 驱动代码
 *
 * @license     Copyright (c) 2020-2032, 广州市星翼电子科技有限公司
 ****************************************************************************************************
 * @attention
 *
 * 实验平台:正点原子 ESP32-S3 带外壳版本
 * 在线视频:www.yuanzige.com
 * 技术论坛:www.openedv.com
 * 公司网址:www.alientek.com
 * 购买地址:openedv.taobao.com
 *
 ****************************************************************************************************
 */

#ifndef __CHSC5XXX_H
#define __CHSC5XXX_H

#include "gpio.h"
#include "../TPIIC/tp_iic.h"
#include "touch.h"
#include "fpioa.h"

/*****************************HARDWARE-PIN*********************************/
/* 硬件IO口，与原理图对应 */
#define PIN_CT_RST              (15)
#define PIN_IMU_SCL             (22)
#define PIN_IMU_SDA             (23)

/*****************************SOFTWARE-GPIO********************************/
/* 软件GPIO口，与程序对应 */
#define CT_RST_GPIONUM          (4)

/*****************************FUNC-GPIO************************************/
/* GPIO口的功能，绑定到硬件IO口 */
#define FUNC_CT_RST              (FUNC_GPIO0 + CT_RST_GPIONUM)
#define FUNC_ICM_SCL             (FUNC_I2C0_SCLK)
#define FUNC_ICM_SDA             (FUNC_I2C0_SDA)

/* 触摸屏复位 */
#define CT_RST(x)       do { x ?                               \
                            gpio_set_pin(CT_RST_GPIONUM, GPIO_PV_HIGH):   \
                            gpio_set_pin(CT_RST_GPIONUM, GPIO_PV_LOW);   \
                        } while(0)

#define CHSC5432_ADDR                    0x2E        /* 7位地址->请看《Application?Note?for?CTPM_CHSC5xxx》 */

/* CHSC5XXX 寄存器  */
#define CHSCXXX_CTRL_REG                 0x2000002C  /* 触摸事件 */
#define CHSCXXX_PID_REG                  0x20000080  /* 读取ID */


/* 函数声明 */
uint8_t chsc5xxx_init(void);
uint8_t chsc5xxx_scan(uint8_t mode);
unsigned char chsc5xxx_wr_reg(uint32_t reg, uint8_t *buf, uint8_t len);
unsigned char chsc5xxx_rd_reg(uint32_t reg, uint8_t *buf, uint8_t len);

#endif
