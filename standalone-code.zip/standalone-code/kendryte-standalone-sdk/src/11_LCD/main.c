/**
 ****************************************************************************************************
 * @file        main.c
 * @author      正点原子团队(ALIENTEK)
 * @version     V1.0
 * @date        2024-01-01
 * @brief       LCD显示 实验
 * @license     Copyright (c) 2020-2032, 广州市星翼电子科技有限公司
 ****************************************************************************************************
 * @attention
 *
 * 实验平台:正点原子 K210开发板
 * 在线视频:www.yuanzige.com
 * 技术论坛:www.openedv.com
 * 公司网址:www.alientek.com
 * 购买地址:openedv.taobao.com
 ****************************************************************************************************
 */

#include "sysctl.h"
#include "sleep.h"
#include "logo.h"
#include "./BSP/TOUCH/touch.h"
#include "./BSP/LCD/lcd.h"

/**
 * @brief       清空屏幕并在右上角显示"RST"
 * @param       无
 * @retval      无
 */
void load_draw_dialog(void)
{
    lcd_clear(WHITE);                                                  /* 清屏 */
    lcd_draw_string(320 - 24, 0, "RST", BLUE);  /* 显示清屏区域 */
}

/**
 * @brief       画粗线
 * @param       x1,y1:起点坐标
 * @param       x2,y2:终点坐标
 * @param       size :线条粗细程度
 * @param       color:线的颜色
 * @retval      无
 */
void lcd_draw_bline(uint16_t x1, uint16_t y1, uint16_t x2, uint16_t y2, uint8_t size, uint16_t color)
{
    uint16_t t;
    int xerr = 0, yerr = 0, delta_x, delta_y, distance;
    int incx, incy, row, col;
    
    if (x1 < size || x2 < size || y1 < size || y2 < size)
    {
        return;
    }
    
    delta_x = x2 - x1;                              /* 计算坐标增量 */
    delta_y = y2 - y1;
    row = x1;
    col = y1;
    
    if (delta_x > 0)
    {
        incx = 1;                                   /* 设置单步方向 */
    }
    else if (delta_x == 0)
    {
        incx = 0;                                   /* 垂直线 */
    }
    else
    {
        incx = -1;
        delta_x = -delta_x;
    }
    
    if (delta_y > 0)
    {
        incy = 1;
    }
    else if (delta_y == 0)
    {
        incy = 0;                                   /* 水平线 */
    }
    else
    {
        incy = -1;
        delta_y = -delta_y;
    }
    
    if ( delta_x > delta_y)
    {
        distance = delta_x;                         /* 选取基本增量坐标轴 */
    }
    else 
    {
        distance = delta_y;
    }
    
    for (t = 0; t <= distance + 1; t++ )            /* 画线输出 */
    {
        lcd_draw_point(row, col, color);     /* 画点 */
        xerr += delta_x ;
        yerr += delta_y ;
        
        if (xerr > distance)
        {
            xerr -= distance;
            row += incx;
        }
        
        if (yerr > distance)
        {
            yerr -= distance;
            col += incy;
        }
    }
}

/* 6个触控点的颜色(电容触摸屏用) */
static const uint16_t POINT_COLOR_TBL[6] = {
    RED,
    GREEN,
    BLUE,
    YELLOW,
    MAGENTA,
    CYAN,
};

/**
 * @brief       电容触摸屏测试函数
 * @param       无
 * @retval      无
 */
void ctp_test(void)
{
    uint8_t t = 0;
    uint8_t i = 0;
    uint16_t lastpos[10][2];
    
    while (1)
    {
        tp_dev.scan(0);
        
        for (t = 0; t < 5; t++)
        {
            if ((tp_dev.sta) & (1 << t))
            {
                if (tp_dev.x[t] < 320 && tp_dev.y[t] < 480)                                               /* 坐标在屏幕范围内 */
                {
                    if (lastpos[t][0] == 0XFFFF)
                    {
                        lastpos[t][0] = tp_dev.x[t];
                        lastpos[t][1] = tp_dev.y[t];
                    }
                    
                    lcd_draw_bline(lastpos[t][0], lastpos[t][1], tp_dev.x[t], tp_dev.y[t], 2, POINT_COLOR_TBL[t]);  /* 画线 */
                    lastpos[t][0] = tp_dev.x[t];
                    lastpos[t][1] = tp_dev.y[t];
                    
                    if (tp_dev.x[t] > (320 - 24) && tp_dev.y[t] < 20)
                    {
                        load_draw_dialog();                                                                         /* 清除 */
                    }
                }
            }
            else 
            {
                lastpos[t][0] = 0xFFFF;
            }
        }
        
        msleep(5);
        i++;
        
        if (i % 20 == 0)
        {
            // LED_TOGGLE();
        }
    }
}

int main(void)
{
    uint8_t x = 0;

    sysctl_pll_set_freq(SYSCTL_PLL0, 800000000);
    sysctl_pll_set_freq(SYSCTL_PLL1, 400000000);
    sysctl_pll_set_freq(SYSCTL_PLL2, 45158400);
    sysctl_set_power_mode(SYSCTL_POWER_BANK6, SYSCTL_POWER_V18);
    sysctl_set_power_mode(SYSCTL_POWER_BANK7, SYSCTL_POWER_V18);
    sysctl_set_spi0_dvp_data(1);

    lcd_init();
    lcd_set_direction(DIR_YX_LRUD);
    /* 显示图片 */
    // lcd_draw_picture(0, 0, 240, 240, gImage_atk_logo);
    // sleep(10);
    
    tp_dev.init();                      /* 初始化触摸屏 */
    load_draw_dialog();
    ctp_test();
    while(1)
    {
        switch(x)
        {
            case 0:lcd_clear(WHITE);break;
            case 1:lcd_clear(BLACK);break;
            case 2:lcd_clear(BLUE);break;
            case 3:lcd_clear(RED);break;
            case 4:lcd_clear(MAGENTA);break;
            case 5:lcd_clear(GREEN);break;
            case 6:lcd_clear(CYAN);break; 
            case 7:lcd_clear(YELLOW);break;
            case 8:lcd_clear(BRRED);break;
            case 9:lcd_clear(GRAY);break;
            case 10:lcd_clear(LIGHTGREY);break;
            case 11:lcd_clear(BROWN);break;
        }	

        lcd_draw_string(10, 10, "ATK-DNK210", RED);
        lcd_draw_string(10, 30, "LCD", RED);
        lcd_draw_string(10, 50, "ATOM@ALIENTEK", RED); 

		if(++x == 12)
        {
            x=0;
        }

		sleep(1);	
	}       
}
