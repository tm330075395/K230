/**
 ****************************************************************************************************
 * @file        recoder.c
 * @author      正点原子团队(ALIENTEK)
 * @version     V1.0
 * @date        2024-01-01
 * @brief       录音机 应用代码
 * @license     Copyright (c) 2020-2032, 广州市星翼电子科技有限公司
 ****************************************************************************************************
 * @attention
 *
 * 实验平台:正点原子 K210开发板
 * 在线视频:www.yuanzige.com
 * 技术论坛:www.openedv.com
 * 公司网址:www.alientek.com
 * 购买地址:openedv.taobao.com
 *
 ****************************************************************************************************
 */

#include "recorder.h"
#include "sysctl.h"
#include <stddef.h>
#include <stdio.h>
#include "wavplay.h" 
#include "sleep.h" 
#include "iomem.h"
#include "i2s.h"
#include "./BSP/FATFS/ff.h"
#include "string.h"
#include "gpio.h"
#include "./BSP/KEY/key.h"
#include "./BSP/LCD/lcd.h"
#include "image_process.h"

uint8_t g_index = 0;
extern uint16_t lcd_gram[320 * 16];
uint32_t *p_i2s_recbuf1;     /* I2S 接收缓冲指针1 */
uint32_t *p_i2s_recbuf2;     /* I2S 接收缓冲指针2 */
int16_t  *rx_buf;

/**
 * REC录音FIFO管理参数.
 * 由于FATFS文件写入时间的不确定性,如果直接在接收中断里面写文件,可能导致某次写入时间过长
 * 从而引起数据丢失,故加入FIFO控制,以解决此问题
 */
volatile uint8_t g_i2s_recfifo_rdpos = 0;           /* 录音FIFO 读位置 */
volatile uint8_t g_i2s_recfifo_wrpos = 0;           /* 录音FIFO 写位置 */
uint8_t * p_i2s_recfifo_buf[REC_I2S_RX_FIFO_SIZE];  /* 录音接收FIFO数组指针 */

uint32_t g_wav_size;        /* wav数据大小(字节数,不包括文件头!!) */
uint8_t g_rec_sta = 0;      /**
                             * 录音状态
                             * [7]:0,没有开启录音;1,已经开启录音;
                             * [6:1]:保留
                             * [0]:0,正在录音;1,暂停录音;
                             */



/**
 * @brief       读取一个录音FIFO
 * @param       buf:  数据缓存区首地址
 * @retval      0, 没有数据可读;
 *              1, 读到了1个数据块;
 */
uint8_t recoder_i2s_fifo_read(uint8_t **buf)
{
    if (g_i2s_recfifo_rdpos == g_i2s_recfifo_wrpos)     /* 读位置  =  写位置, 说明没得数据可读 */
    {
        return 0;
    }
    
    g_i2s_recfifo_rdpos++;          /* 读位置加1 */

    if (g_i2s_recfifo_rdpos >= REC_I2S_RX_FIFO_SIZE)    /* 读位置超过了总FIFO数, 归零重新开始 */
    {
        g_i2s_recfifo_rdpos = 0;    /* 归零 */
    }
    
    *buf = p_i2s_recfifo_buf[g_i2s_recfifo_rdpos];      /* 返回对应FIFO BUF的地址 */

    return 1;
}


/**
 * @brief       写一个录音FIFO
 * @param       buf:  数据缓存区首地址
 * @retval      0, 写入成功;
 *              1, 写入失败;
 */
uint8_t recoder_i2s_fifo_write(uint8_t *buf)
{
    uint16_t i;
    uint8_t temp = g_i2s_recfifo_wrpos; /* 记录当前写位置 */
    g_i2s_recfifo_wrpos++;              /* 写位置加1 */

    if (g_i2s_recfifo_wrpos >= REC_I2S_RX_FIFO_SIZE)    /* 写位置超过了总FIFO数, 归零重新开始 */
    {
        g_i2s_recfifo_wrpos = 0;        /* 归零 */
    }
    
    if (g_i2s_recfifo_wrpos == g_i2s_recfifo_rdpos)     /* 写位置  =  读位置, 说明没得位置可写了 */
    {
        g_i2s_recfifo_wrpos = temp;     /* 还原原来的写位置,此次写入失败 */
        return 1;
    }

    for (i = 0; i < REC_I2S_RX_DMA_BUF_SIZE; i++)       /* 循环写数据 */
    {
        p_i2s_recfifo_buf[g_i2s_recfifo_wrpos][i] = buf[i];
    }

    return 0;
}

int i2s_receive_dma_cb(void *ctx)
{
    uint32_t i = 0;
    if (g_rec_sta == 0X80)   /* 录音模式 */
    {
        if(g_index)
        {
            /* 接收DMA数据 */
            i2s_receive_data_dma(I2S_DEVICE_0, p_i2s_recbuf1, REC_I2S_RX_DMA_BUF_SIZE / 2, DMAC_CHANNEL1);
             /* 需要对数据初步处理，使用的时16位宽双声道，一个声音占32位 */
            for(i = 0; i < REC_I2S_RX_DMA_BUF_SIZE / 4; i++)
            {
                /* 保存数据 */
                rx_buf[2 * i] = (int16_t)((p_i2s_recbuf2[2 * i + 1] * MIC_GAIN) & 0xffff);
                rx_buf[2 * i + 1] = (int16_t)((p_i2s_recbuf2[2 * i + 1] * MIC_GAIN) & 0xffff);
            }
            recoder_i2s_fifo_write((uint8_t *)rx_buf);
            g_index = 0;
        }
        else
        {
            i2s_receive_data_dma(I2S_DEVICE_0, p_i2s_recbuf2, REC_I2S_RX_DMA_BUF_SIZE / 2, DMAC_CHANNEL1);
            for(i = 0; i < REC_I2S_RX_DMA_BUF_SIZE / 4; i++)
            {
                /* 保存数据 */
                rx_buf[2 * i] = (int16_t)((p_i2s_recbuf1[2 * i + 1] * MIC_GAIN) & 0xffff);
                rx_buf[2 * i + 1] = (int16_t)((p_i2s_recbuf1[2 * i + 1] * MIC_GAIN) & 0xffff);
            }
            recoder_i2s_fifo_write((uint8_t *)rx_buf);
            g_index = 1;
        }
    }
    return 0;
}

/**
 * @brief       进入PCM 录音模式
 * @param       无
 * @retval      无
 */
void recoder_enter_rec_mode(void)
{
    /* I2S设备0初始化为接收模式 */
    i2s_init(I2S_DEVICE_0, I2S_RECEIVER, 0x0C);

    /* 通道参数设置 */
    i2s_rx_channel_config(
        I2S_DEVICE_0, /* I2S设备0 */
        I2S_CHANNEL_1, /* 通道1 */
        RESOLUTION_16_BIT, /* 接收数据16bit */
        SCLK_CYCLES_32, /* 单个数据时钟为32 */
        TRIGGER_LEVEL_4, /* FIFO深度为4 */

        STANDARD_MODE); /* 标准模式 */
    /* 设置采样率 */
    i2s_set_sample_rate(I2S_DEVICE_0, REC_SAMPLERATE);

    /* 设置DMA中断回调 */
    dmac_set_irq(DMAC_CHANNEL1, i2s_receive_dma_cb, NULL, 4);
}


/**
 * @brief       初始化WAV头
 * @param       wavhead : wav文件头指针
 * @retval      无
 */
void recoder_wav_init(__WaveHeader *wavhead)
{
    wavhead->riff.ChunkID = 0X46464952;     /* RIFF" */
    wavhead->riff.ChunkSize = 0;            /* 还未确定,最后需要计算 */
    wavhead->riff.Format = 0X45564157;      /* "WAVE" */
    wavhead->fmt.ChunkID = 0X20746D66;      /* "fmt " */
    wavhead->fmt.ChunkSize = 16;            /* 大小为16个字节 */
    wavhead->fmt.AudioFormat = 0X01;        /* 0X01,表示PCM;0X01,表示IMA ADPCM */
    wavhead->fmt.NumOfChannels = 2;         /* 双声道 */
    wavhead->fmt.SampleRate = REC_SAMPLERATE;               /* 采样速率 */
    wavhead->fmt.ByteRate = wavhead->fmt.SampleRate * 4;    /* 字节速率=采样率*通道数*(ADC位数/8) */
    wavhead->fmt.BlockAlign = 4;            /* 块大小=通道数*(ADC位数/8) */
    wavhead->fmt.BitsPerSample = 16;        /* 16位PCM */
    wavhead->data.ChunkID = 0X61746164;     /* "data" */
    wavhead->data.ChunkSize = 0;            /* 数据大小,还需要计算 */
}

/**
 * @brief       通过时间获取文件名
 *   @note      仅限在SD卡保存,不支持FLASH DISK保存
 *   @note      组合成:形如"0:RECORDER/REC00001.wav"的文件名
 * @param       pname : 文件路径
 * @retval      无
 */
void recoder_new_pathname(uint8_t *pname)
{
    uint8_t res;
    uint16_t index = 0;
    FIL *ftemp;
    ftemp = (FIL *)iomem_malloc(sizeof(FIL));   /* 开辟FIL字节的内存区域 */

    if (ftemp == NULL) return;  /* 内存申请失败 */

    while (index < 0XFFFF)
    {
        sprintf((char *)pname, "0:RECORDER/REC%05d.wav", index);
        res = f_open(ftemp, (const TCHAR *)pname, FA_READ); /* 尝试打开这个文件 */

        if (res == FR_NO_FILE)
        {
            break;              /* 该文件名不存在=正是我们需要的. */
        }

        index++;
    }

    iomem_free(ftemp);
}

/**
 * @brief       WAV录音
 * @param       无
 * @retval      无
 */
void wav_recorder(void)
{
    uint8_t res, i;
    uint8_t key;
    uint8_t rval = 0;
    uint32_t bw;
    char datashow[15];

    __WaveHeader *wavhead = 0;
    DIR recdir;             /* 目录 */
    FIL *f_rec = 0;         /* 录音文件 */

    uint8_t *pdatabuf;      /* 数据缓存指针 */
    uint8_t *pname = 0;
    uint32_t recsec = 0;    /* 录音时间 */

    while (f_opendir(&recdir, "0:/RECORDER"))   /* 打开录音文件夹 */
    {
        msleep(200);
        f_mkdir("0:/RECORDER");                 /* 创建该目录 */
    }
    /* 申请内存 */
    for (i = 0; i < REC_I2S_RX_FIFO_SIZE; i++)
    {
        p_i2s_recfifo_buf[i] = iomem_malloc(REC_I2S_RX_DMA_BUF_SIZE); /* I2S录音FIFO内存申请 */

        if (p_i2s_recfifo_buf[i] == NULL)
        {
            break;  /* 申请失败 */
        }
    }

    p_i2s_recbuf1 = iomem_malloc(REC_I2S_RX_DMA_BUF_SIZE / 2);      /* I2S录音内存1申请 */
    p_i2s_recbuf2 = iomem_malloc(REC_I2S_RX_DMA_BUF_SIZE / 2);      /* I2S录音内存2申请 */
    rx_buf = iomem_malloc(REC_I2S_RX_DMA_BUF_SIZE / 2); 
    f_rec = (FIL *)iomem_malloc(sizeof(FIL));                   /* 开辟FIL字节的内存区域 */
    wavhead = (__WaveHeader *)iomem_malloc(sizeof(__WaveHeader));   /* 开辟__WaveHeader字节的内存区域 */
    pname = iomem_malloc(30);   /* 申请30个字节内存,类似"0:RECORDER/REC00001.wav" */
    if (!p_i2s_recbuf2 || !f_rec || !wavhead || !pname)rval = 1;    /* 任意一项失败, 则失败 */

    if (rval == 0)
    {
        recoder_enter_rec_mode();   /* 进入录音模式 */
        pname[0] = 0;               /* pname没有任何文件名 */

        while (rval == 0)
        {
            key = key_scan(0);
            switch (key)
            {
               case KEY0_PRES:     /* 开始录音 */
                    recsec = 0;
                    recoder_new_pathname(pname);    /* 得到新的名字 */
                    recoder_wav_init(wavhead);      /* 初始化wav数据 */
                    res = f_open(f_rec, (const TCHAR *)pname, FA_CREATE_ALWAYS | FA_WRITE);

                    if (res)            /* 文件创建失败 */
                    {
                        g_rec_sta = 0;  /* 创建文件失败,不能录音 */
                        rval = 0XFE;    /* 提示是否存在SD卡 */
                    }
                    else
                    {
                        res = f_write(f_rec, (const void *)wavhead, sizeof(__WaveHeader), &bw);         /* 写入头数据 */
                        g_rec_sta |= 0X80;  /* 开始录音 */
                        /* I2S通过DMA接收数据，保存到rx_buf中 */
                        i2s_receive_data_dma(I2S_DEVICE_0, p_i2s_recbuf1, REC_I2S_RX_DMA_BUF_SIZE, DMAC_CHANNEL1);
                    }
                    break;

                case KEY1_PRES: /*REC/PAUSE */
                    if (g_rec_sta & 0X01)           /* 原来是暂停,继续录音 */
                    {
                        g_rec_sta &= 0XFE;          /* 取消暂停 */
                        /* I2S通过DMA接收数据，保存到rx_buf中 */
                        i2s_receive_data_dma(I2S_DEVICE_0, p_i2s_recbuf1, REC_I2S_RX_DMA_BUF_SIZE, DMAC_CHANNEL1);
                    }
                    else if (g_rec_sta & 0X80)      /* 已经在录音了,暂停 */
                    {
                        g_rec_sta |= 0X01;          /* 暂停 */
                    }
                    else    /* 还没开始录音 */
                    {
                        recsec = 0;
                        recoder_new_pathname(pname);    /* 得到新的名字 */
                        recoder_wav_init(wavhead);      /* 初始化wav数据 */
                        res = f_open(f_rec, (const TCHAR *)pname, FA_CREATE_ALWAYS | FA_WRITE);

                        if (res)            /* 文件创建失败 */
                        {
                            g_rec_sta = 0;  /* 创建文件失败,不能录音 */
                            rval = 0XFE;    /* 提示是否存在SD卡 */
                        }
                        else
                        {
                            res = f_write(f_rec, (const void *)wavhead, sizeof(__WaveHeader), &bw);         /* 写入头数据 */
                            g_rec_sta |= 0X80;  /* 开始录音 */
                            /* I2S通过DMA接收数据，保存到rx_buf中 */
                            i2s_receive_data_dma(I2S_DEVICE_0, p_i2s_recbuf1, REC_I2S_RX_DMA_BUF_SIZE, DMAC_CHANNEL1);
                        }
                    }
                    key = 0;
                    break;
                case KEY2_PRES:     /* STOP&SAVE */
                    if (g_rec_sta & 0X80)   /* 有录音 */
                    {
                        g_rec_sta = 0;      /* 关闭录音 */
                        wavhead->riff.ChunkSize = g_wav_size + 36;  /* 整个文件的大小-8; */
                        wavhead->data.ChunkSize = g_wav_size;       /* 数据大小 */
                        f_lseek(f_rec, 0);                          /* 偏移到文件头. */
                        f_write(f_rec, (const void *)wavhead, sizeof(__WaveHeader), &bw);   /* 写入头数据 */
                        f_close(f_rec);
                        g_wav_size = 0;
                    }

                    g_rec_sta = 0;
                    recsec = 0;
                    g_index = 0;
                    key = 0;
                    break;
            }

            if (recoder_i2s_fifo_read(&pdatabuf))   /* 读取一次数据, 读到数据了,写入文件 */
            {
                res = f_write(f_rec, pdatabuf, REC_I2S_RX_DMA_BUF_SIZE, &bw); /* 写入文件 */
                if (res)
                {
                    printf("write error:%d\r\n", res);
                }

                g_wav_size += REC_I2S_RX_DMA_BUF_SIZE;  /* WAV数据大小增加 */
            }
            else
            {
                msleep(1);
            }

            if (recsec != (g_wav_size / wavhead->fmt.ByteRate)) /* 录音时间显示 */
            {
                recsec = g_wav_size / wavhead->fmt.ByteRate;    /* 录音时间 */
                sprintf((char *)datashow, "time:%02d:%02d", (uint16_t)(recsec / 60), (uint16_t)(recsec % 60));

                for (size_t i = 0; i < 320 * 16; i++)
                {
                    lcd_gram[i] = 0xFFFF;
                }
                draw_string_rgb565_image(lcd_gram, 320, 240, 10, 0, (char *)datashow, BLUE);
                lcd_draw_picture(0, 70, 320, 16, (uint16_t *)lcd_gram); 
            }
        }
    }
    
    for (i = 0; i < REC_I2S_RX_FIFO_SIZE; i++)
    {
        iomem_free(p_i2s_recfifo_buf[i]);   /* SAI录音FIFO内存释放 */
    }
    
    iomem_free(p_i2s_recbuf1);  /* 释放内存 */
    iomem_free(p_i2s_recbuf2);  /* 释放内存 */
    iomem_free(f_rec);          /* 释放内存 */
    iomem_free(wavhead);        /* 释放内存 */

    iomem_free(pname);          /* 释放内存 */
}

