/**
 ****************************************************************************************************
 * @file        mic.c
 * @author      正点原子团队(ALIENTEK)
 * @version     V1.0
 * @date        2024-01-01
 * @brief       麦克风接口 驱动代码
 * @license     Copyright (c) 2020-2032, 广州市星翼电子科技有限公司
 ****************************************************************************************************
 * @attention
 * 
 * 实验平台:正点原子 K210开发板
 * 在线视频:www.yuanzige.com
 * 技术论坛:www.openedv.com
 * 公司网址:www.alientek.com
 * 购买地址:openedv.taobao.com
 *
 ****************************************************************************************************
 */

#include "mic.h"
#include "fpioa.h"
#include "gpio.h"

/**
 * @brief       麦克风引脚初始化，绑定GPIO功能
 * @param       无
 * @retval      返回值 : 无
 */
void mic_i2s_hardware_init(void)
{
    /* mic */
    fpioa_set_function(PIN_MIC_WS,   FUNC_MIC_WS);
    fpioa_set_function(PIN_MIC_SDIN, FUNC_MIC_SDIN);
    fpioa_set_function(PIN_MIC_BCK,  FUNC_MIC_BCK);

    /* I2S 初始化 */
    gpio_init();    /* 使能GPIO的时钟 */
    
    fpioa_set_function(PIN_SPK_CTRL, FUNC_SPK_CTRL);
    gpio_set_drive_mode(SPK_CTRL_GPIONUM, GPIO_DM_OUTPUT);  /*输出模式*/
    gpio_set_pin(SPK_CTRL_GPIONUM, GPIO_PV_LOW); /*输出为低，使能麦克风输入*/
}
