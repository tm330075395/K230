    该文件夹下面存放中间层组件代码，包括：
    1，正点原子提供的中间层代码：USMART、MALLOC、TEXT、T9INPUT、PICTURE、GUI、MJPEG、各种ATK开头的LIB、NES、SMS、QR_ENCODE等
    2，第三方中间层代码：FATFS、USB、LWIP、各种OS、各种GUI等 

    注意：该文件夹下面，要到视频播放实验，才会存放代码进来，在此之前的例程，没有用到类似的代码，但是我们会预留该文件夹，方便后续工程使用。



 ***********************************************************************************************************
 * 公司名称：广州市星翼电子科技有限公司（正点原子）
 * 电话号码：020-38271790
 * 传真号码：020-36773971
 * 公司网址：www.alientek.com
 * 购买地址：zhengdianyuanzi.tmall.com
 * 技术论坛：http://www.openedv.com/forum.php
 * 最新资料：www.openedv.com/docs/index.html
 *
 * 在线视频：www.yuanzige.com
 * B 站视频：space.bilibili.com/394620890
 * 公 众 号 ：mp.weixin.qq.com/s/y--mG3qQT8gop0VRuER9bw
 * 抖     音 ：douyin.com/user/MS4wLjABAAAAi5E95JUBpqsW5kgMEaagtIITIl15hAJvMO8vQMV1tT6PEsw-V5HbkNLlLMkFf1Bd
 ***********************************************************************************************************